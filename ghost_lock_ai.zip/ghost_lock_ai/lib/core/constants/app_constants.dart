class AppConstants {
  // App Identity
  static const String appName    = 'Ghost Lock AI';
  static const String appVersion = '1.0.0';

  // Disguise modes
  static const String disguiseCalculator = 'calculator';
  static const String disguiseNotes      = 'notes';
  static const String disguiseWeather    = 'weather';
  static const String disguiseDiary      = 'diary';

  // Storage Keys
  static const String keyDisguiseMode      = 'disguise_mode';
  static const String keyThemeMode         = 'theme_mode';
  static const String keySetupComplete     = 'setup_complete';
  static const String keySecretMethod      = 'secret_method';
  static const String keyVoicePassphrase   = 'voice_passphrase';
  static const String keyPatternHash       = 'pattern_hash';
  static const String keyTapSequenceHash   = 'tap_sequence_hash';
  static const String keyMaxAttempts       = 'max_attempts';
  static const String keyLockDuration     = 'lock_duration_minutes';
  static const String keyCaptureOnFail    = 'capture_on_fail';
  static const String keyEncryptionKey    = 'encryption_key';
  static const String keyOwnerVoiceModel  = 'owner_voice_model';

  // Vault sections
  static const String sectionPhotos    = 'photos';
  static const String sectionVideos    = 'videos';
  static const String sectionFiles     = 'files';
  static const String sectionNotes     = 'notes';

  // Entry modes
  static const String entryModeVault      = 'vault';       // main vault
  static const String entryModeDeveloper  = 'developer';   // dev mode
  static const String entryModeDecoy      = 'decoy';       // fake vault (duress)

  // Security
  static const int defaultMaxAttempts    = 5;
  static const int defaultLockMinutes    = 10;
  static const int tapSequenceLength     = 6;

  // Database
  static const String dbName           = 'ghost_lock.db';
  static const String tableVaultItems  = 'vault_items';
  static const String tableFolders     = 'vault_folders';
  static const String tableAttempts    = 'auth_attempts';
  static const String tableNotes       = 'secure_notes';

  // Hive box names
  static const String hiveBoxSettings  = 'settings';
  static const String hiveBoxVault     = 'vault';
  static const String hiveBoxSecurity  = 'security';

  // Animation durations (ms)
  static const int animFast    = 200;
  static const int animNormal  = 350;
  static const int animSlow    = 600;
  static const int animEnter   = 800;
}

class SecretPhraseResult {
  static const String openVault     = 'vault';
  static const String openDeveloper = 'developer';
  static const String openDecoy     = 'decoy';
  static const String denied        = 'denied';
}
