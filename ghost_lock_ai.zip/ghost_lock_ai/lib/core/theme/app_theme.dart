import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class AppTheme {
  // ── Brand Palette ──────────────────────────────────────────────
  static const Color ghostBlue       = Color(0xFF0D1B2A);
  static const Color vaultAccent     = Color(0xFF00D4FF);
  static const Color vaultAccentGlow = Color(0x3300D4FF);
  static const Color dangerRed       = Color(0xFFFF3B5C);
  static const Color successGreen    = Color(0xFF00E5A0);
  static const Color warningAmber    = Color(0xFFFFB800);
  static const Color surfaceDark     = Color(0xFF111827);
  static const Color cardDark        = Color(0xFF1C2B3A);
  static const Color cardDarker      = Color(0xFF141E2A);
  static const Color borderColor     = Color(0xFF1E3448);
  static const Color textPrimary     = Color(0xFFF0F4F8);
  static const Color textSecondary   = Color(0xFF8BA5C0);
  static const Color textMuted       = Color(0xFF4A6072);

  // Light palette
  static const Color lightBg         = Color(0xFFF0F4F8);
  static const Color lightSurface    = Color(0xFFFFFFFF);
  static const Color lightCard       = Color(0xFFF8FAFC);
  static const Color lightBorder     = Color(0xFFE2EAF0);
  static const Color lightTextPrim   = Color(0xFF0D1B2A);
  static const Color lightTextSec    = Color(0xFF5A7A96);

  static ThemeData darkTheme = ThemeData(
    useMaterial3: true,
    brightness: Brightness.dark,
    scaffoldBackgroundColor: surfaceDark,
    colorScheme: ColorScheme.dark(
      primary: vaultAccent,
      secondary: vaultAccent,
      surface: cardDark,
      background: surfaceDark,
      error: dangerRed,
      onPrimary: ghostBlue,
      onSurface: textPrimary,
    ),
    textTheme: GoogleFonts.cairoTextTheme(
      ThemeData.dark().textTheme,
    ).copyWith(
      displayLarge: GoogleFonts.cairo(
        fontSize: 32, fontWeight: FontWeight.w700,
        color: textPrimary, letterSpacing: -0.5,
      ),
      displayMedium: GoogleFonts.cairo(
        fontSize: 26, fontWeight: FontWeight.w700,
        color: textPrimary,
      ),
      titleLarge: GoogleFonts.cairo(
        fontSize: 20, fontWeight: FontWeight.w600,
        color: textPrimary,
      ),
      titleMedium: GoogleFonts.cairo(
        fontSize: 16, fontWeight: FontWeight.w600,
        color: textPrimary,
      ),
      bodyLarge: GoogleFonts.cairo(
        fontSize: 15, fontWeight: FontWeight.w400,
        color: textPrimary,
      ),
      bodyMedium: GoogleFonts.cairo(
        fontSize: 13, fontWeight: FontWeight.w400,
        color: textSecondary,
      ),
      labelSmall: GoogleFonts.cairo(
        fontSize: 11, fontWeight: FontWeight.w500,
        color: textMuted, letterSpacing: 0.8,
      ),
    ),
    cardTheme: CardTheme(
      color: cardDark,
      elevation: 0,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(16),
        side: const BorderSide(color: borderColor, width: 1),
      ),
      margin: EdgeInsets.zero,
    ),
    appBarTheme: AppBarTheme(
      backgroundColor: surfaceDark,
      elevation: 0,
      scrolledUnderElevation: 0,
      centerTitle: true,
      titleTextStyle: GoogleFonts.cairo(
        fontSize: 18, fontWeight: FontWeight.w700,
        color: textPrimary,
      ),
      iconTheme: const IconThemeData(color: textPrimary),
    ),
    elevatedButtonTheme: ElevatedButtonThemeData(
      style: ElevatedButton.styleFrom(
        backgroundColor: vaultAccent,
        foregroundColor: ghostBlue,
        elevation: 0,
        padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 14),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12),
        ),
        textStyle: GoogleFonts.cairo(
          fontSize: 15, fontWeight: FontWeight.w700,
        ),
      ),
    ),
    iconTheme: const IconThemeData(color: textSecondary, size: 22),
    dividerTheme: const DividerThemeData(
      color: borderColor, thickness: 1, space: 0,
    ),
    inputDecorationTheme: InputDecorationTheme(
      filled: true,
      fillColor: cardDarker,
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide: const BorderSide(color: borderColor),
      ),
      enabledBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide: const BorderSide(color: borderColor),
      ),
      focusedBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide: const BorderSide(color: vaultAccent, width: 1.5),
      ),
      labelStyle: GoogleFonts.cairo(color: textSecondary),
      hintStyle: GoogleFonts.cairo(color: textMuted),
      contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
    ),
  );

  static ThemeData lightTheme = ThemeData(
    useMaterial3: true,
    brightness: Brightness.light,
    scaffoldBackgroundColor: lightBg,
    colorScheme: const ColorScheme.light(
      primary: Color(0xFF0077B6),
      secondary: Color(0xFF0077B6),
      surface: lightSurface,
      background: lightBg,
      error: dangerRed,
      onPrimary: Colors.white,
      onSurface: lightTextPrim,
    ),
    textTheme: GoogleFonts.cairoTextTheme(
      ThemeData.light().textTheme,
    ),
    cardTheme: CardTheme(
      color: lightSurface,
      elevation: 0,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(16),
        side: const BorderSide(color: lightBorder, width: 1),
      ),
      margin: EdgeInsets.zero,
    ),
  );
}

// ── Design Tokens ─────────────────────────────────────────────────
class AppRadius {
  static const double sm  = 8.0;
  static const double md  = 12.0;
  static const double lg  = 16.0;
  static const double xl  = 24.0;
  static const double xxl = 32.0;
}

class AppSpacing {
  static const double xs  = 4.0;
  static const double sm  = 8.0;
  static const double md  = 16.0;
  static const double lg  = 24.0;
  static const double xl  = 32.0;
  static const double xxl = 48.0;
}

class AppDuration {
  static const Duration fast   = Duration(milliseconds: 200);
  static const Duration normal = Duration(milliseconds: 350);
  static const Duration slow   = Duration(milliseconds: 600);
  static const Duration enter  = Duration(milliseconds: 800);
}
