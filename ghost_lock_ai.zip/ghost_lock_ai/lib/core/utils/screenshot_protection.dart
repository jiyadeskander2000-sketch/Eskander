import 'package:flutter/services.dart';

/// Bridges Flutter ↔ Android native for FLAG_SECURE screenshot protection
class ScreenshotProtection {
  static const _channel = MethodChannel('ghost_lock/security');

  /// Call this when entering the vault
  static Future<void> enable() async {
    try {
      await _channel.invokeMethod('enableScreenshotProtection');
    } on PlatformException catch (_) {
      // Silently ignore — non-critical
    }
  }

  /// Call this when returning to disguise screen
  static Future<void> disable() async {
    try {
      await _channel.invokeMethod('disableScreenshotProtection');
    } on PlatformException catch (_) {}
  }

  static Future<bool> isEnabled() async {
    try {
      return await _channel.invokeMethod('isScreenshotProtected') ?? false;
    } on PlatformException catch (_) {
      return false;
    }
  }
}
