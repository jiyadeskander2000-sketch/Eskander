import 'dart:convert';
import 'dart:math';
import 'dart:typed_data';
import 'package:crypto/crypto.dart';
import 'package:encrypt/encrypt.dart' as enc;
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import '../constants/app_constants.dart';

class EncryptionService {
  static const _storage = FlutterSecureStorage(
    aOptions: AndroidOptions(encryptedSharedPreferences: true),
  );

  // ── Key Management ───────────────────────────────────────────────
  static Future<String> getOrCreateKey() async {
    String? existingKey = await _storage.read(key: AppConstants.keyEncryptionKey);
    if (existingKey != null) return existingKey;

    final key = _generateSecureKey(32);
    await _storage.write(key: AppConstants.keyEncryptionKey, value: key);
    return key;
  }

  static String _generateSecureKey(int length) {
    final random = Random.secure();
    final bytes  = List<int>.generate(length, (_) => random.nextInt(256));
    return base64Url.encode(bytes);
  }

  // ── AES-256 Text Encryption ──────────────────────────────────────
  static Future<String> encryptText(String plainText) async {
    final keyStr = await getOrCreateKey();
    final keyBytes = base64Url.decode(keyStr.padRight(
      ((keyStr.length + 3) ~/ 4) * 4, '=',
    ));
    final key = enc.Key(Uint8List.fromList(keyBytes.take(32).toList()));
    final iv  = enc.IV.fromSecureRandom(16);
    final encrypter = enc.Encrypter(enc.AES(key, mode: enc.AESMode.cbc));
    final encrypted = encrypter.encrypt(plainText, iv: iv);
    // Prepend IV to ciphertext
    return '${iv.base64}:${encrypted.base64}';
  }

  static Future<String> decryptText(String cipherText) async {
    final parts  = cipherText.split(':');
    if (parts.length != 2) throw Exception('Invalid cipher format');
    final keyStr = await getOrCreateKey();
    final keyBytes = base64Url.decode(keyStr.padRight(
      ((keyStr.length + 3) ~/ 4) * 4, '=',
    ));
    final key = enc.Key(Uint8List.fromList(keyBytes.take(32).toList()));
    final iv  = enc.IV.fromBase64(parts[0]);
    final encrypter = enc.Encrypter(enc.AES(key, mode: enc.AESMode.cbc));
    return encrypter.decrypt64(parts[1], iv: iv);
  }

  // ── File Encryption ──────────────────────────────────────────────
  static Future<Uint8List> encryptBytes(Uint8List data) async {
    final keyStr = await getOrCreateKey();
    final keyBytes = base64Url.decode(keyStr.padRight(
      ((keyStr.length + 3) ~/ 4) * 4, '=',
    ));
    final key = enc.Key(Uint8List.fromList(keyBytes.take(32).toList()));
    final iv  = enc.IV.fromSecureRandom(16);
    final encrypter = enc.Encrypter(enc.AES(key, mode: enc.AESMode.cbc));
    final encrypted = encrypter.encryptBytes(data, iv: iv);
    // Return: [16 bytes IV] + [encrypted data]
    return Uint8List.fromList([...iv.bytes, ...encrypted.bytes]);
  }

  static Future<Uint8List> decryptBytes(Uint8List data) async {
    final keyStr = await getOrCreateKey();
    final keyBytes = base64Url.decode(keyStr.padRight(
      ((keyStr.length + 3) ~/ 4) * 4, '=',
    ));
    final key = enc.Key(Uint8List.fromList(keyBytes.take(32).toList()));
    final ivBytes = data.sublist(0, 16);
    final cipherBytes = data.sublist(16);
    final iv = enc.IV(ivBytes);
    final encrypter = enc.Encrypter(enc.AES(key, mode: enc.AESMode.cbc));
    return Uint8List.fromList(
      encrypter.decryptBytes(enc.Encrypted(cipherBytes), iv: iv),
    );
  }

  // ── Hashing ──────────────────────────────────────────────────────
  static String hashPassphrase(String passphrase) {
    final bytes  = utf8.encode(passphrase.trim().toLowerCase());
    final digest = sha256.convert(bytes);
    return digest.toString();
  }

  static bool verifyPassphrase(String input, String storedHash) {
    return hashPassphrase(input) == storedHash;
  }

  // ── Secret Key Generation ────────────────────────────────────────
  static String generateSmartPassword({
    int length = 16,
    bool includeSymbols = true,
  }) {
    const lower   = 'abcdefghijklmnopqrstuvwxyz';
    const upper   = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
    const digits  = '0123456789';
    const symbols = '!@#\$%^&*()_+-=[]{}|;:,.<>?';
    final chars   = lower + upper + digits + (includeSymbols ? symbols : '');
    final random  = Random.secure();
    return List.generate(length, (_) => chars[random.nextInt(chars.length)]).join();
  }
}
