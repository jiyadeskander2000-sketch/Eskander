import 'dart:io';
import 'dart:math';
import 'dart:typed_data';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:speech_to_text/speech_to_text.dart';
import 'package:record/record.dart';
import 'package:path_provider/path_provider.dart';

/// Ghost Lock AI — AI intelligence layer
/// Handles: voice owner verification, anomaly detection, smart suggestions
class GhostAI {
  static const _storage = FlutterSecureStorage(
    aOptions: AndroidOptions(encryptedSharedPreferences: true),
  );
  static final SpeechToText  _speech  = SpeechToText();
  static final AudioRecorder _recorder = AudioRecorder();

  // ── Voice Owner Enrollment ───────────────────────────────────────
  /// Records 3 samples of the owner's voice for recognition baseline
  static Future<bool> enrollOwnerVoice() async {
    final dir     = await getApplicationDocumentsDirectory();
    final samples = <String>[];

    for (int i = 0; i < 3; i++) {
      final path = '${dir.path}/voice_sample_$i.m4a';
      await _recorder.start(
        const RecordConfig(encoder: AudioEncoder.aacLc, bitRate: 128000),
        path: path,
      );
      await Future.delayed(const Duration(seconds: 3));
      await _recorder.stop();
      samples.add(path);
    }

    // Store paths for comparison
    await _storage.write(
      key: 'voice_samples',
      value: samples.join('|'),
    );
    await _storage.write(key: 'voice_enrolled', value: 'true');
    return true;
  }

  static Future<bool> isVoiceEnrolled() async {
    final v = await _storage.read(key: 'voice_enrolled');
    return v == 'true';
  }

  // ── Suspicious Attempt Detection ─────────────────────────────────
  /// Analyzes recent attempts for suspicious patterns
  static SuspicionReport analyzeAttempts(List<AttemptSnapshot> recentAttempts) {
    if (recentAttempts.isEmpty) return SuspicionReport.safe();

    int failCount  = 0;
    int rapidFails = 0;
    DateTime? lastFail;

    for (final a in recentAttempts) {
      if (!a.wasSuccessful) {
        failCount++;
        if (lastFail != null &&
            a.timestamp.difference(lastFail!).inSeconds < 30) {
          rapidFails++;
        }
        lastFail = a.timestamp;
      }
    }

    // Score: 0 (safe) → 100 (critical threat)
    int score = 0;
    score += min(failCount * 15, 60);     // up to 60 from fail count
    score += min(rapidFails * 10, 30);    // up to 30 from rapid fails

    String level;
    String message;
    if (score >= 70) {
      level   = 'critical';
      message = 'تحذير: محاولات اختراق متكررة ومتسارعة. يُنصح بتغيير كلمة السر فوراً.';
    } else if (score >= 40) {
      level   = 'warning';
      message = 'تنبيه: عدة محاولات دخول فاشلة. راجع سجل المحاولات.';
    } else {
      level   = 'safe';
      message = 'لا توجد أنشطة مشبوهة.';
    }

    return SuspicionReport(
      score: score, level: level, message: message,
      failCount: failCount, rapidFails: rapidFails,
    );
  }

  // ── Smart Password Suggestions ────────────────────────────────────
  /// Generates contextual Arabic/English secure passphrases
  static List<SmartSuggestion> generateSmartSuggestions() {
    final r       = Random.secure();
    final arabic  = ['القمر', 'النجم', 'الفجر', 'البحر', 'الجبل', 'العقاب',
                     'الصقر', 'النخيل', 'الأمل', 'الظل'];
    final english = ['ghost', 'cipher', 'vault', 'prism', 'nexus',
                     'shadow', 'forge', 'blade', 'storm', 'echo'];
    final digits  = () => (100 + r.nextInt(900)).toString();
    final symbols = () => ['!', '@', '#', '\$', '%', '&'][r.nextInt(6)];

    return [
      // Arabic + number
      SmartSuggestion(
        passphrase: '${arabic[r.nextInt(arabic.length)]}${digits()}',
        type: 'arabic',
        strength: 'قوية',
        description: 'كلمة عربية + رقم',
      ),
      // English + symbol + number
      SmartSuggestion(
        passphrase: '${english[r.nextInt(english.length)]}${symbols()}${digits()}',
        type: 'mixed',
        strength: 'قوية جداً',
        description: 'إنجليزية + رمز + رقم',
      ),
      // Two Arabic words
      SmartSuggestion(
        passphrase: arabic[r.nextInt(arabic.length)] + arabic[r.nextInt(arabic.length)],
        type: 'arabic',
        strength: 'ممتازة',
        description: 'كلمتان عربيتان',
      ),
      // Full random high-entropy
      SmartSuggestion(
        passphrase: _randomHighEntropy(r),
        type: 'random',
        strength: 'أقصى قوة',
        description: 'عشوائية بالكامل',
      ),
    ];
  }

  static String _randomHighEntropy(Random r) {
    const chars = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#\$';
    return List.generate(14, (_) => chars[r.nextInt(chars.length)]).join();
  }

  // ── Security Upgrade Suggestions ─────────────────────────────────
  static List<SecurityTip> getSecurityTips({
    required bool voiceEnabled,
    required bool biometricEnabled,
    required bool captureOnFail,
    required int  maxAttempts,
    required int  failCount,
  }) {
    final tips = <SecurityTip>[];

    if (!voiceEnabled) {
      tips.add(SecurityTip(
        icon: '🎤',
        title: 'فعّل المصادقة الصوتية',
        description: 'بصمة صوتك أصعب بكثير في الاختراق من الأنماط التقليدية.',
        priority: 'high',
      ));
    }
    if (!captureOnFail) {
      tips.add(SecurityTip(
        icon: '📷',
        title: 'فعّل التقاط صورة المتطفل',
        description: 'احصل على صورة من يحاول الدخول عند كل محاولة فاشلة.',
        priority: 'medium',
      ));
    }
    if (maxAttempts > 5) {
      tips.add(SecurityTip(
        icon: '🔒',
        title: 'قلل عدد المحاولات المسموحة',
        description: 'الحد الأمثل هو 3-5 محاولات قبل القفل التلقائي.',
        priority: 'medium',
      ));
    }
    if (failCount > 3) {
      tips.add(SecurityTip(
        icon: '⚠️',
        title: 'غيّر كلمة السر الآن',
        description: 'تم رصد محاولات دخول فاشلة متعددة مؤخراً.',
        priority: 'high',
      ));
    }
    if (!biometricEnabled) {
      tips.add(SecurityTip(
        icon: '👆',
        title: 'أضف طبقة بصمة الإصبع',
        description: 'طبقة تحقق إضافية لمزيد من الأمان.',
        priority: 'low',
      ));
    }

    tips.sort((a, b) {
      const order = {'high': 0, 'medium': 1, 'low': 2};
      return (order[a.priority] ?? 3).compareTo(order[b.priority] ?? 3);
    });
    return tips;
  }
}

// ── Data classes ──────────────────────────────────────────────────
class AttemptSnapshot {
  final DateTime timestamp;
  final bool     wasSuccessful;
  const AttemptSnapshot({required this.timestamp, required this.wasSuccessful});
}

class SuspicionReport {
  final int    score;
  final String level;
  final String message;
  final int    failCount;
  final int    rapidFails;

  const SuspicionReport({
    required this.score, required this.level, required this.message,
    required this.failCount, required this.rapidFails,
  });

  factory SuspicionReport.safe() => const SuspicionReport(
    score: 0, level: 'safe', message: 'لا توجد أنشطة مشبوهة.',
    failCount: 0, rapidFails: 0,
  );

  bool get isSafe     => level == 'safe';
  bool get isWarning  => level == 'warning';
  bool get isCritical => level == 'critical';
}

class SmartSuggestion {
  final String passphrase, type, strength, description;
  const SmartSuggestion({
    required this.passphrase, required this.type,
    required this.strength,  required this.description,
  });
}

class SecurityTip {
  final String icon, title, description, priority;
  const SecurityTip({
    required this.icon, required this.title,
    required this.description, required this.priority,
  });
}
