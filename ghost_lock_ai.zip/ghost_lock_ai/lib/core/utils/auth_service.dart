import 'dart:async';
import 'dart:math';
import 'package:flutter/material.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:speech_to_text/speech_to_text.dart';
import '../constants/app_constants.dart';
import 'encryption_service.dart';

// ── Auth Result ────────────────────────────────────────────────────
enum AuthResult { vault, developer, decoy, denied, locked }

class AuthService {
  static const _storage = FlutterSecureStorage(
    aOptions: AndroidOptions(encryptedSharedPreferences: true),
  );
  static final SpeechToText _speech = SpeechToText();

  // ── Lock State ───────────────────────────────────────────────────
  static int    _failedAttempts = 0;
  static DateTime? _lockedUntil;

  static bool get isLocked {
    if (_lockedUntil == null) return false;
    if (DateTime.now().isAfter(_lockedUntil!)) {
      _lockedUntil = null;
      _failedAttempts = 0;
      return false;
    }
    return true;
  }

  static Duration get remainingLockTime {
    if (_lockedUntil == null) return Duration.zero;
    final remaining = _lockedUntil!.difference(DateTime.now());
    return remaining.isNegative ? Duration.zero : remaining;
  }

  // ── Passphrase Setup ─────────────────────────────────────────────
  static Future<void> setupPassphrases({
    required String vaultPhrase,
    String? developerPhrase,
    String? decoyPhrase,
  }) async {
    await _storage.write(
      key: 'vault_phrase_hash',
      value: EncryptionService.hashPassphrase(vaultPhrase),
    );
    if (developerPhrase != null && developerPhrase.isNotEmpty) {
      await _storage.write(
        key: 'developer_phrase_hash',
        value: EncryptionService.hashPassphrase(developerPhrase),
      );
    }
    if (decoyPhrase != null && decoyPhrase.isNotEmpty) {
      await _storage.write(
        key: 'decoy_phrase_hash',
        value: EncryptionService.hashPassphrase(decoyPhrase),
      );
    }
  }

  // ── Voice Authentication ─────────────────────────────────────────
  static Future<bool> initSpeech() => _speech.initialize();

  static Future<AuthResult> authenticateByVoice() async {
    if (isLocked) return AuthResult.locked;

    final completer = Completer<AuthResult>();
    bool available = await _speech.initialize(
      onError: (_) => completer.complete(AuthResult.denied),
    );
    if (!available) return AuthResult.denied;

    await _speech.listen(
      onResult: (result) async {
        if (result.finalResult) {
          final spoken = result.recognizedWords.trim().toLowerCase();
          await _speech.stop();
          final authResult = await _matchPassphrase(spoken);
          if (!completer.isCompleted) completer.complete(authResult);
        }
      },
      listenFor: const Duration(seconds: 8),
      pauseFor: const Duration(seconds: 3),
      localeId: 'ar-YE',
    );

    return completer.future.timeout(
      const Duration(seconds: 10),
      onTimeout: () => AuthResult.denied,
    );
  }

  static Future<AuthResult> _matchPassphrase(String input) async {
    final vaultHash  = await _storage.read(key: 'vault_phrase_hash');
    final devHash    = await _storage.read(key: 'developer_phrase_hash');
    final decoyHash  = await _storage.read(key: 'decoy_phrase_hash');

    if (vaultHash != null && EncryptionService.verifyPassphrase(input, vaultHash)) {
      _resetAttempts();
      return AuthResult.vault;
    }
    if (devHash != null && EncryptionService.verifyPassphrase(input, devHash)) {
      _resetAttempts();
      return AuthResult.developer;
    }
    if (decoyHash != null && EncryptionService.verifyPassphrase(input, decoyHash)) {
      _resetAttempts();
      return AuthResult.decoy;
    }

    return _handleFailedAttempt();
  }

  // ── Tap Sequence Authentication ──────────────────────────────────
  static Future<void> saveTapSequence(List<int> sequence) async {
    final hash = EncryptionService.hashPassphrase(sequence.join('-'));
    await _storage.write(key: AppConstants.keyTapSequenceHash, value: hash);
  }

  static Future<AuthResult> authenticateByTaps(List<int> sequence) async {
    if (isLocked) return AuthResult.locked;
    final stored = await _storage.read(key: AppConstants.keyTapSequenceHash);
    if (stored == null) return AuthResult.denied;
    final hash = EncryptionService.hashPassphrase(sequence.join('-'));
    if (hash == stored) {
      _resetAttempts();
      return AuthResult.vault;
    }
    return _handleFailedAttempt();
  }

  // ── Pattern Authentication ───────────────────────────────────────
  static Future<void> savePattern(List<Offset> pattern) async {
    final normalized = pattern.map((p) => '${p.dx.toStringAsFixed(2)},${p.dy.toStringAsFixed(2)}').join('|');
    final hash = EncryptionService.hashPassphrase(normalized);
    await _storage.write(key: AppConstants.keyPatternHash, value: hash);
  }

  static Future<AuthResult> authenticateByPattern(List<Offset> pattern) async {
    if (isLocked) return AuthResult.locked;
    final stored = await _storage.read(key: AppConstants.keyPatternHash);
    if (stored == null) return AuthResult.denied;
    final normalized = pattern.map((p) => '${p.dx.toStringAsFixed(2)},${p.dy.toStringAsFixed(2)}').join('|');
    final hash = EncryptionService.hashPassphrase(normalized);
    if (hash == stored) {
      _resetAttempts();
      return AuthResult.vault;
    }
    return _handleFailedAttempt();
  }

  // ── Swipe Gesture Authentication ─────────────────────────────────
  static Future<void> saveSwipeSequence(List<String> directions) async {
    final hash = EncryptionService.hashPassphrase(directions.join('-'));
    await _storage.write(key: 'swipe_sequence_hash', value: hash);
  }

  static Future<AuthResult> authenticateBySwipe(List<String> directions) async {
    if (isLocked) return AuthResult.locked;
    final stored = await _storage.read(key: 'swipe_sequence_hash');
    if (stored == null) return AuthResult.denied;
    final hash = EncryptionService.hashPassphrase(directions.join('-'));
    if (hash == stored) {
      _resetAttempts();
      return AuthResult.vault;
    }
    return _handleFailedAttempt();
  }

  // ── Tap Position Authentication (secret zones) ───────────────────
  // User taps specific positions on screen in order
  static Future<void> saveTapZones(List<String> zoneIds) async {
    final hash = EncryptionService.hashPassphrase(zoneIds.join('-'));
    await _storage.write(key: 'tap_zones_hash', value: hash);
  }

  static Future<AuthResult> authenticateByZones(List<String> zoneIds) async {
    if (isLocked) return AuthResult.locked;
    final stored = await _storage.read(key: 'tap_zones_hash');
    if (stored == null) return AuthResult.denied;
    final hash = EncryptionService.hashPassphrase(zoneIds.join('-'));
    if (hash == stored) {
      _resetAttempts();
      return AuthResult.vault;
    }
    return _handleFailedAttempt();
  }

  // ── Attempt Management ───────────────────────────────────────────
  static AuthResult _handleFailedAttempt() {
    _failedAttempts++;
    if (_failedAttempts >= AppConstants.defaultMaxAttempts) {
      _lockedUntil = DateTime.now().add(
        const Duration(minutes: AppConstants.defaultLockMinutes),
      );
    }
    return AuthResult.denied;
  }

  static void _resetAttempts() {
    _failedAttempts = 0;
    _lockedUntil    = null;
  }

  static int get failedAttempts => _failedAttempts;
  static int get remainingAttempts => max(0, AppConstants.defaultMaxAttempts - _failedAttempts);

  // ── Setup Check ──────────────────────────────────────────────────
  static Future<bool> isSetupComplete() async {
    final hash = await _storage.read(key: 'vault_phrase_hash');
    return hash != null && hash.isNotEmpty;
  }
}
