import 'package:equatable/equatable.dart';

// ── VaultItem Entity ───────────────────────────────────────────────
class VaultItem extends Equatable {
  final String   id;
  final String   folderId;
  final String   type;         // photo | video | file | note
  final String   name;
  final String   encryptedPath;
  final String?  thumbnailPath;
  final int      sizeBytes;
  final DateTime createdAt;
  final DateTime modifiedAt;
  final bool     isFavorite;
  final Map<String, dynamic> metadata;

  const VaultItem({
    required this.id,
    required this.folderId,
    required this.type,
    required this.name,
    required this.encryptedPath,
    this.thumbnailPath,
    required this.sizeBytes,
    required this.createdAt,
    required this.modifiedAt,
    this.isFavorite = false,
    this.metadata   = const {},
  });

  @override
  List<Object?> get props => [id, folderId, type, name, encryptedPath,
    thumbnailPath, sizeBytes, createdAt, modifiedAt, isFavorite, metadata];

  VaultItem copyWith({
    String? id, String? folderId, String? type, String? name,
    String? encryptedPath, String? thumbnailPath, int? sizeBytes,
    DateTime? createdAt, DateTime? modifiedAt, bool? isFavorite,
    Map<String, dynamic>? metadata,
  }) => VaultItem(
    id: id ?? this.id,
    folderId: folderId ?? this.folderId,
    type: type ?? this.type,
    name: name ?? this.name,
    encryptedPath: encryptedPath ?? this.encryptedPath,
    thumbnailPath: thumbnailPath ?? this.thumbnailPath,
    sizeBytes: sizeBytes ?? this.sizeBytes,
    createdAt: createdAt ?? this.createdAt,
    modifiedAt: modifiedAt ?? this.modifiedAt,
    isFavorite: isFavorite ?? this.isFavorite,
    metadata: metadata ?? this.metadata,
  );
}

// ── VaultFolder Entity ─────────────────────────────────────────────
class VaultFolder extends Equatable {
  final String   id;
  final String   name;
  final String?  parentId;
  final String   color;
  final String   icon;
  final int      itemCount;
  final DateTime createdAt;

  const VaultFolder({
    required this.id,
    required this.name,
    this.parentId,
    this.color    = '#00D4FF',
    this.icon     = 'folder',
    this.itemCount = 0,
    required this.createdAt,
  });

  @override
  List<Object?> get props => [id, name, parentId, color, icon, itemCount, createdAt];
}

// ── SecureNote Entity ──────────────────────────────────────────────
class SecureNote extends Equatable {
  final String   id;
  final String   folderId;
  final String   title;
  final String   encryptedContent;
  final bool     isPinned;
  final String   color;
  final List<String> tags;
  final DateTime createdAt;
  final DateTime modifiedAt;

  const SecureNote({
    required this.id,
    required this.folderId,
    required this.title,
    required this.encryptedContent,
    this.isPinned = false,
    this.color    = '#1C2B3A',
    this.tags     = const [],
    required this.createdAt,
    required this.modifiedAt,
  });

  @override
  List<Object?> get props => [id, folderId, title, encryptedContent,
    isPinned, color, tags, createdAt, modifiedAt];
}

// ── AuthAttempt Entity ─────────────────────────────────────────────
class AuthAttempt extends Equatable {
  final String   id;
  final DateTime timestamp;
  final bool     wasSuccessful;
  final String   method;          // voice | tap | pattern | swipe
  final String?  capturedImagePath;
  final String?  deviceInfo;
  final String   ipAddress;

  const AuthAttempt({
    required this.id,
    required this.timestamp,
    required this.wasSuccessful,
    required this.method,
    this.capturedImagePath,
    this.deviceInfo,
    this.ipAddress = 'local',
  });

  @override
  List<Object?> get props => [id, timestamp, wasSuccessful, method,
    capturedImagePath, deviceInfo, ipAddress];
}

// ── SecuritySettings Entity ────────────────────────────────────────
class SecuritySettings extends Equatable {
  final int    maxAttempts;
  final int    lockDurationMinutes;
  final bool   captureOnFail;
  final bool   screenshotProtection;
  final bool   voiceAuthEnabled;
  final bool   biometricEnabled;
  final String entryMethod;   // voice | tap | pattern | swipe

  const SecuritySettings({
    this.maxAttempts          = 5,
    this.lockDurationMinutes  = 10,
    this.captureOnFail        = true,
    this.screenshotProtection = true,
    this.voiceAuthEnabled     = false,
    this.biometricEnabled     = false,
    this.entryMethod          = 'tap',
  });

  @override
  List<Object?> get props => [maxAttempts, lockDurationMinutes, captureOnFail,
    screenshotProtection, voiceAuthEnabled, biometricEnabled, entryMethod];
}
