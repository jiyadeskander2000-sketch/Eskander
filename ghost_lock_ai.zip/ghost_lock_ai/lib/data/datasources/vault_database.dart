import 'dart:async';
import 'package:path/path.dart';
import 'package:sqflite/sqflite.dart';
import '../../core/constants/app_constants.dart';
import '../../domain/entities/vault_entities.dart';
import 'package:uuid/uuid.dart';

class VaultDatabase {
  static Database? _db;
  static const _uuid = Uuid();

  static Future<Database> get database async {
    _db ??= await _initDb();
    return _db!;
  }

  static Future<Database> _initDb() async {
    final dbPath = await getDatabasesPath();
    final path   = join(dbPath, AppConstants.dbName);

    return openDatabase(
      path,
      version: 1,
      onCreate: _onCreate,
      onConfigure: (db) async => await db.execute('PRAGMA foreign_keys = ON'),
    );
  }

  static Future<void> _onCreate(Database db, int version) async {
    await db.execute('''
      CREATE TABLE ${AppConstants.tableFolders} (
        id          TEXT PRIMARY KEY,
        name        TEXT NOT NULL,
        parent_id   TEXT,
        color       TEXT DEFAULT '#00D4FF',
        icon        TEXT DEFAULT 'folder',
        item_count  INTEGER DEFAULT 0,
        created_at  TEXT NOT NULL
      )
    ''');

    await db.execute('''
      CREATE TABLE ${AppConstants.tableVaultItems} (
        id              TEXT PRIMARY KEY,
        folder_id       TEXT NOT NULL,
        type            TEXT NOT NULL,
        name            TEXT NOT NULL,
        encrypted_path  TEXT NOT NULL,
        thumbnail_path  TEXT,
        size_bytes      INTEGER DEFAULT 0,
        is_favorite     INTEGER DEFAULT 0,
        metadata        TEXT DEFAULT '{}',
        created_at      TEXT NOT NULL,
        modified_at     TEXT NOT NULL,
        FOREIGN KEY (folder_id) REFERENCES ${AppConstants.tableFolders}(id)
          ON DELETE CASCADE
      )
    ''');

    await db.execute('''
      CREATE TABLE ${AppConstants.tableNotes} (
        id                TEXT PRIMARY KEY,
        folder_id         TEXT NOT NULL,
        title             TEXT NOT NULL,
        encrypted_content TEXT NOT NULL,
        is_pinned         INTEGER DEFAULT 0,
        color             TEXT DEFAULT '#1C2B3A',
        tags              TEXT DEFAULT '[]',
        created_at        TEXT NOT NULL,
        modified_at       TEXT NOT NULL
      )
    ''');

    await db.execute('''
      CREATE TABLE ${AppConstants.tableAttempts} (
        id                   TEXT PRIMARY KEY,
        timestamp            TEXT NOT NULL,
        was_successful       INTEGER NOT NULL,
        method               TEXT NOT NULL,
        captured_image_path  TEXT,
        device_info          TEXT,
        ip_address           TEXT DEFAULT 'local'
      )
    ''');

    // Insert default "root" folder
    await db.insert(AppConstants.tableFolders, {
      'id':         'root',
      'name':       'الرئيسية',
      'parent_id':  null,
      'color':      '#00D4FF',
      'icon':       'folder',
      'item_count': 0,
      'created_at': DateTime.now().toIso8601String(),
    });
  }

  // ── Folders ──────────────────────────────────────────────────────
  static Future<List<VaultFolder>> getFolders({String? parentId}) async {
    final db   = await database;
    final rows = await db.query(
      AppConstants.tableFolders,
      where: parentId != null ? 'parent_id = ?' : null,
      whereArgs: parentId != null ? [parentId] : null,
      orderBy: 'created_at ASC',
    );
    return rows.map(_folderFromRow).toList();
  }

  static Future<VaultFolder> createFolder({
    required String name, String? parentId,
    String color = '#00D4FF', String icon = 'folder',
  }) async {
    final db     = await database;
    final folder = VaultFolder(
      id: _uuid.v4(), name: name, parentId: parentId,
      color: color, icon: icon, createdAt: DateTime.now(),
    );
    await db.insert(AppConstants.tableFolders, _folderToRow(folder));
    return folder;
  }

  static Future<void> deleteFolder(String id) async {
    if (id == 'root') return; // protect root
    final db = await database;
    await db.delete(AppConstants.tableFolders,
      where: 'id = ?', whereArgs: [id]);
  }

  // ── Vault Items ──────────────────────────────────────────────────
  static Future<List<VaultItem>> getItems({
    String? folderId, String? type,
  }) async {
    final db  = await database;
    final conditions = <String>[];
    final args       = <dynamic>[];
    if (folderId != null) { conditions.add('folder_id = ?'); args.add(folderId); }
    if (type     != null) { conditions.add('type = ?');      args.add(type);     }

    final rows = await db.query(
      AppConstants.tableVaultItems,
      where: conditions.isEmpty ? null : conditions.join(' AND '),
      whereArgs: args.isEmpty ? null : args,
      orderBy: 'created_at DESC',
    );
    return rows.map(_itemFromRow).toList();
  }

  static Future<VaultItem> insertItem(VaultItem item) async {
    final db = await database;
    await db.insert(AppConstants.tableVaultItems, _itemToRow(item));
    await _updateFolderCount(db, item.folderId, 1);
    return item;
  }

  static Future<void> deleteItem(String id) async {
    final db   = await database;
    final rows = await db.query(AppConstants.tableVaultItems,
      where: 'id = ?', whereArgs: [id], columns: ['folder_id']);
    if (rows.isNotEmpty) {
      final folderId = rows.first['folder_id'] as String;
      await db.delete(AppConstants.tableVaultItems,
        where: 'id = ?', whereArgs: [id]);
      await _updateFolderCount(db, folderId, -1);
    }
  }

  static Future<void> toggleFavorite(String id, bool value) async {
    final db = await database;
    await db.update(
      AppConstants.tableVaultItems,
      {'is_favorite': value ? 1 : 0, 'modified_at': DateTime.now().toIso8601String()},
      where: 'id = ?', whereArgs: [id],
    );
  }

  static Future<List<VaultItem>> searchItems(String query) async {
    final db   = await database;
    final rows = await db.query(
      AppConstants.tableVaultItems,
      where: 'name LIKE ?',
      whereArgs: ['%$query%'],
      orderBy: 'modified_at DESC',
    );
    return rows.map(_itemFromRow).toList();
  }

  static Future<void> _updateFolderCount(Database db, String folderId, int delta) async {
    await db.rawUpdate(
      'UPDATE ${AppConstants.tableFolders} SET item_count = item_count + ? WHERE id = ?',
      [delta, folderId],
    );
  }

  // ── Secure Notes ─────────────────────────────────────────────────
  static Future<List<SecureNote>> getNotes({String? folderId}) async {
    final db   = await database;
    final rows = await db.query(
      AppConstants.tableNotes,
      where: folderId != null ? 'folder_id = ?' : null,
      whereArgs: folderId != null ? [folderId] : null,
      orderBy: 'is_pinned DESC, modified_at DESC',
    );
    return rows.map(_noteFromRow).toList();
  }

  static Future<SecureNote> insertNote(SecureNote note) async {
    final db = await database;
    await db.insert(AppConstants.tableNotes, _noteToRow(note));
    return note;
  }

  static Future<void> updateNote(SecureNote note) async {
    final db = await database;
    await db.update(AppConstants.tableNotes, _noteToRow(note),
      where: 'id = ?', whereArgs: [note.id]);
  }

  static Future<void> deleteNote(String id) async {
    final db = await database;
    await db.delete(AppConstants.tableNotes, where: 'id = ?', whereArgs: [id]);
  }

  // ── Auth Attempts ─────────────────────────────────────────────────
  static Future<void> logAttempt(AuthAttempt attempt) async {
    final db = await database;
    await db.insert(AppConstants.tableAttempts, {
      'id':                  attempt.id,
      'timestamp':           attempt.timestamp.toIso8601String(),
      'was_successful':      attempt.wasSuccessful ? 1 : 0,
      'method':              attempt.method,
      'captured_image_path': attempt.capturedImagePath,
      'device_info':         attempt.deviceInfo,
      'ip_address':          attempt.ipAddress,
    });
  }

  static Future<List<AuthAttempt>> getAttempts({int limit = 50}) async {
    final db   = await database;
    final rows = await db.query(
      AppConstants.tableAttempts,
      orderBy: 'timestamp DESC',
      limit: limit,
    );
    return rows.map((r) => AuthAttempt(
      id:                 r['id'] as String,
      timestamp:          DateTime.parse(r['timestamp'] as String),
      wasSuccessful:      (r['was_successful'] as int) == 1,
      method:             r['method'] as String,
      capturedImagePath:  r['captured_image_path'] as String?,
      deviceInfo:         r['device_info'] as String?,
      ipAddress:          r['ip_address'] as String? ?? 'local',
    )).toList();
  }

  static Future<void> clearAttempts() async {
    final db = await database;
    await db.delete(AppConstants.tableAttempts);
  }

  // ── Stats ─────────────────────────────────────────────────────────
  static Future<Map<String, int>> getVaultStats() async {
    final db = await database;
    final photos = Sqflite.firstIntValue(await db.rawQuery(
      "SELECT COUNT(*) FROM ${AppConstants.tableVaultItems} WHERE type='photo'")) ?? 0;
    final videos = Sqflite.firstIntValue(await db.rawQuery(
      "SELECT COUNT(*) FROM ${AppConstants.tableVaultItems} WHERE type='video'")) ?? 0;
    final files  = Sqflite.firstIntValue(await db.rawQuery(
      "SELECT COUNT(*) FROM ${AppConstants.tableVaultItems} WHERE type='file'")) ?? 0;
    final notes  = Sqflite.firstIntValue(await db.rawQuery(
      "SELECT COUNT(*) FROM ${AppConstants.tableNotes}")) ?? 0;
    return {'photos': photos, 'videos': videos, 'files': files, 'notes': notes};
  }

  // ── Mappers ───────────────────────────────────────────────────────
  static VaultFolder _folderFromRow(Map<String, dynamic> r) => VaultFolder(
    id: r['id'] as String, name: r['name'] as String,
    parentId: r['parent_id'] as String?, color: r['color'] as String,
    icon: r['icon'] as String, itemCount: r['item_count'] as int,
    createdAt: DateTime.parse(r['created_at'] as String),
  );

  static Map<String, dynamic> _folderToRow(VaultFolder f) => {
    'id': f.id, 'name': f.name, 'parent_id': f.parentId,
    'color': f.color, 'icon': f.icon, 'item_count': f.itemCount,
    'created_at': f.createdAt.toIso8601String(),
  };

  static VaultItem _itemFromRow(Map<String, dynamic> r) => VaultItem(
    id: r['id'] as String, folderId: r['folder_id'] as String,
    type: r['type'] as String, name: r['name'] as String,
    encryptedPath: r['encrypted_path'] as String,
    thumbnailPath: r['thumbnail_path'] as String?,
    sizeBytes: r['size_bytes'] as int,
    isFavorite: (r['is_favorite'] as int) == 1,
    createdAt: DateTime.parse(r['created_at'] as String),
    modifiedAt: DateTime.parse(r['modified_at'] as String),
  );

  static Map<String, dynamic> _itemToRow(VaultItem i) => {
    'id': i.id, 'folder_id': i.folderId, 'type': i.type,
    'name': i.name, 'encrypted_path': i.encryptedPath,
    'thumbnail_path': i.thumbnailPath, 'size_bytes': i.sizeBytes,
    'is_favorite': i.isFavorite ? 1 : 0,
    'created_at': i.createdAt.toIso8601String(),
    'modified_at': i.modifiedAt.toIso8601String(),
  };

  static SecureNote _noteFromRow(Map<String, dynamic> r) => SecureNote(
    id: r['id'] as String, folderId: r['folder_id'] as String,
    title: r['title'] as String,
    encryptedContent: r['encrypted_content'] as String,
    isPinned: (r['is_pinned'] as int) == 1,
    color: r['color'] as String,
    createdAt: DateTime.parse(r['created_at'] as String),
    modifiedAt: DateTime.parse(r['modified_at'] as String),
  );

  static Map<String, dynamic> _noteToRow(SecureNote n) => {
    'id': n.id, 'folder_id': n.folderId, 'title': n.title,
    'encrypted_content': n.encryptedContent,
    'is_pinned': n.isPinned ? 1 : 0, 'color': n.color,
    'tags': '[]',
    'created_at': n.createdAt.toIso8601String(),
    'modified_at': n.modifiedAt.toIso8601String(),
  };
}
