import 'package:equatable/equatable.dart';
import '../../core/utils/auth_service.dart';

// ── Events ─────────────────────────────────────────────────────────
abstract class AuthEvent extends Equatable {
  @override List<Object?> get props => [];
}

class AuthVoiceStarted    extends AuthEvent {}
class AuthVoiceStopped    extends AuthEvent {}
class AuthTapSubmitted    extends AuthEvent {
  final List<int> sequence;
  AuthTapSubmitted(this.sequence);
  @override List<Object?> get props => [sequence];
}
class AuthPatternSubmitted extends AuthEvent {
  final List<dynamic> pattern;
  AuthPatternSubmitted(this.pattern);
  @override List<Object?> get props => [pattern];
}
class AuthSwipeSubmitted  extends AuthEvent {
  final List<String> directions;
  AuthSwipeSubmitted(this.directions);
  @override List<Object?> get props => [directions];
}
class AuthZonesSubmitted  extends AuthEvent {
  final List<String> zoneIds;
  AuthZonesSubmitted(this.zoneIds);
  @override List<Object?> get props => [zoneIds];
}
class AuthReset           extends AuthEvent {}

// ── States ─────────────────────────────────────────────────────────
abstract class AuthState extends Equatable {
  @override List<Object?> get props => [];
}

class AuthInitial          extends AuthState {}
class AuthListening        extends AuthState {}  // voice listening
class AuthLoading          extends AuthState {}

class AuthSuccess extends AuthState {
  final AuthResult mode;
  AuthSuccess(this.mode);
  @override List<Object?> get props => [mode];
}

class AuthFailure extends AuthState {
  final int remainingAttempts;
  final bool shouldCapture;
  AuthFailure({required this.remainingAttempts, this.shouldCapture = true});
  @override List<Object?> get props => [remainingAttempts, shouldCapture];
}

class AuthLocked extends AuthState {
  final Duration remaining;
  AuthLocked(this.remaining);
  @override List<Object?> get props => [remaining];
}

// ── Vault Bloc Events/States ────────────────────────────────────────
abstract class VaultEvent extends Equatable {
  @override List<Object?> get props => [];
}

class VaultLoadItems    extends VaultEvent {
  final String? folderId;
  final String? type;
  VaultLoadItems({this.folderId, this.type});
  @override List<Object?> get props => [folderId, type];
}
class VaultAddItem      extends VaultEvent {
  final String filePath;
  final String type;
  final String folderId;
  VaultAddItem({required this.filePath, required this.type, required this.folderId});
  @override List<Object?> get props => [filePath, type, folderId];
}
class VaultDeleteItem   extends VaultEvent {
  final String itemId;
  VaultDeleteItem(this.itemId);
  @override List<Object?> get props => [itemId];
}
class VaultToggleFavorite extends VaultEvent {
  final String itemId;
  VaultToggleFavorite(this.itemId);
  @override List<Object?> get props => [itemId];
}
class VaultSearchItems  extends VaultEvent {
  final String query;
  VaultSearchItems(this.query);
  @override List<Object?> get props => [query];
}

abstract class VaultState extends Equatable {
  @override List<Object?> get props => [];
}

class VaultInitial  extends VaultState {}
class VaultLoading  extends VaultState {}
class VaultLoaded   extends VaultState {
  final List<dynamic> items;
  final List<dynamic> folders;
  VaultLoaded({required this.items, required this.folders});
  @override List<Object?> get props => [items, folders];
}
class VaultError    extends VaultState {
  final String message;
  VaultError(this.message);
  @override List<Object?> get props => [message];
}
class VaultAdding   extends VaultState {}
class VaultItemAdded extends VaultState {
  final dynamic item;
  VaultItemAdded(this.item);
  @override List<Object?> get props => [item];
}

// ── Settings Bloc Events/States ─────────────────────────────────────
abstract class SettingsEvent extends Equatable {
  @override List<Object?> get props => [];
}

class SettingsLoad            extends SettingsEvent {}
class SettingsChangeDisguise  extends SettingsEvent {
  final String mode;
  SettingsChangeDisguise(this.mode);
  @override List<Object?> get props => [mode];
}
class SettingsToggleTheme     extends SettingsEvent {}
class SettingsUpdateSecurity  extends SettingsEvent {
  final Map<String, dynamic> settings;
  SettingsUpdateSecurity(this.settings);
  @override List<Object?> get props => [settings];
}

abstract class SettingsState extends Equatable {
  @override List<Object?> get props => [];
}
class SettingsInitial extends SettingsState {}
class SettingsLoaded  extends SettingsState {
  final String disguiseMode;
  final bool   isDarkMode;
  final Map<String, dynamic> security;
  SettingsLoaded({
    required this.disguiseMode,
    required this.isDarkMode,
    required this.security,
  });
  @override List<Object?> get props => [disguiseMode, isDarkMode, security];
}
class SettingsUpdated extends SettingsState {
  final SettingsLoaded current;
  SettingsUpdated(this.current);
  @override List<Object?> get props => [current];
}
