import 'dart:io';
import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:image_picker/image_picker.dart';
import 'package:file_picker/file_picker.dart';
import 'package:path_provider/path_provider.dart';
import 'package:path/path.dart' as path;
import 'package:uuid/uuid.dart';
import '../../core/constants/app_constants.dart';
import '../../core/theme/app_theme.dart';
import '../../core/utils/encryption_service.dart';

class VaultSectionScreen extends StatefulWidget {
  final String type;
  const VaultSectionScreen({super.key, required this.type});
  @override State<VaultSectionScreen> createState() => _VaultSectionScreenState();
}

class _VaultSectionScreenState extends State<VaultSectionScreen> {
  final _uuid       = const Uuid();
  final _picker     = ImagePicker();
  bool   _isLoading = false;
  bool   _gridView  = true;
  List<_VaultEntry> _items = [];

  String get _sectionTitle => switch (widget.type) {
    AppConstants.sectionPhotos => 'الصور والفيديو',
    AppConstants.sectionVideos => 'الفيديوهات',
    AppConstants.sectionFiles  => 'الملفات',
    _                          => 'الخزنة',
  };

  IconData get _addIcon => switch (widget.type) {
    AppConstants.sectionPhotos => Icons.add_photo_alternate_outlined,
    AppConstants.sectionVideos => Icons.video_library_outlined,
    _                          => Icons.upload_file_outlined,
  };

  @override
  void initState() {
    super.initState();
    _loadItems();
  }

  Future<void> _loadItems() async {
    // TODO: Load from encrypted SQLite DB
    setState(() => _items = []);
  }

  Future<void> _addItem() async {
    HapticFeedback.mediumImpact();
    if (widget.type == AppConstants.sectionPhotos ||
        widget.type == AppConstants.sectionVideos) {
      await _pickFromGallery();
    } else {
      await _pickFile();
    }
  }

  Future<void> _pickFromGallery() async {
    final ImageSource? source = await showModalBottomSheet<ImageSource>(
      context: context,
      backgroundColor: AppTheme.cardDark,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (_) => _SourcePicker(),
    );
    if (source == null) return;

    final picked = await _picker.pickImage(source: source, imageQuality: 90);
    if (picked == null) return;

    setState(() => _isLoading = true);
    try {
      await _encryptAndStore(picked.path, 'photo');
    } finally {
      setState(() => _isLoading = false);
    }
  }

  Future<void> _pickFile() async {
    final result = await FilePicker.platform.pickFiles(allowMultiple: true);
    if (result == null) return;

    setState(() => _isLoading = true);
    try {
      for (final f in result.files) {
        if (f.path != null) await _encryptAndStore(f.path!, 'file');
      }
    } finally {
      setState(() => _isLoading = false);
    }
  }

  Future<void> _encryptAndStore(String filePath, String type) async {
    final dir = await getApplicationDocumentsDirectory();
    final vaultDir = Directory('${dir.path}/vault/$type');
    await vaultDir.create(recursive: true);

    final rawBytes = await File(filePath).readAsBytes();
    final encrypted = await EncryptionService.encryptBytes(rawBytes);

    final id       = _uuid.v4();
    final ext      = path.extension(filePath);
    final destPath = '${vaultDir.path}/$id.enc';
    await File(destPath).writeAsBytes(encrypted);

    // Save original to delete
    await File(filePath).delete().catchError((_) {});

    setState(() {
      _items.add(_VaultEntry(
        id: id, type: type,
        encryptedPath: destPath,
        name: path.basename(filePath),
        createdAt: DateTime.now(),
      ));
    });
  }

  Future<void> _deleteItem(_VaultEntry item) async {
    final confirm = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: AppTheme.cardDark,
        title: const Text('حذف الملف', style: TextStyle(color: AppTheme.textPrimary)),
        content: const Text('هل تريد حذف هذا الملف نهائياً؟',
          style: TextStyle(color: AppTheme.textSecondary)),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false),
            child: const Text('إلغاء', style: TextStyle(color: AppTheme.textSecondary))),
          TextButton(onPressed: () => Navigator.pop(context, true),
            child: const Text('حذف', style: TextStyle(color: AppTheme.dangerRed))),
        ],
      ),
    );
    if (confirm != true) return;

    await File(item.encryptedPath).delete().catchError((_) {});
    setState(() => _items.remove(item));
    HapticFeedback.mediumImpact();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.surfaceDark,
      appBar: AppBar(
        title: Text(_sectionTitle),
        actions: [
          IconButton(
            icon: Icon(_gridView ? Icons.view_list : Icons.grid_view),
            onPressed: () => setState(() => _gridView = !_gridView),
            color: AppTheme.textSecondary,
          ),
        ],
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator(color: AppTheme.vaultAccent))
          : _items.isEmpty
              ? _buildEmptyState()
              : _gridView ? _buildGrid() : _buildList(),
      floatingActionButton: FloatingActionButton(
        onPressed: _addItem,
        backgroundColor: AppTheme.vaultAccent,
        foregroundColor: AppTheme.ghostBlue,
        child: Icon(_addIcon),
      ),
    );
  }

  Widget _buildEmptyState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(Icons.lock_outline,
            size: 64, color: AppTheme.textMuted),
          const SizedBox(height: 16),
          Text('لا يوجد محتوى مخفي بعد',
            style: Theme.of(context).textTheme.titleMedium?.copyWith(
              color: AppTheme.textSecondary)),
          const SizedBox(height: 8),
          Text('اضغط + لإضافة ملفات إلى الخزنة',
            style: Theme.of(context).textTheme.bodyMedium),
        ],
      ),
    ).animate().fadeIn(duration: 400.ms);
  }

  Widget _buildGrid() {
    return GridView.builder(
      padding: const EdgeInsets.all(16),
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 3, crossAxisSpacing: 8, mainAxisSpacing: 8,
      ),
      itemCount: _items.length,
      itemBuilder: (context, i) {
        final item = _items[i];
        return GestureDetector(
          onLongPress: () => _deleteItem(item),
          child: Container(
            decoration: BoxDecoration(
              color: AppTheme.cardDark,
              borderRadius: BorderRadius.circular(10),
              border: Border.all(color: AppTheme.borderColor),
            ),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(
                  item.type == 'photo' ? Icons.image : Icons.description,
                  color: AppTheme.vaultAccent, size: 28,
                ),
                const SizedBox(height: 4),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 6),
                  child: Text(item.name,
                    maxLines: 2, overflow: TextOverflow.ellipsis,
                    style: const TextStyle(
                      color: AppTheme.textSecondary, fontSize: 9,
                    ), textAlign: TextAlign.center,
                  ),
                ),
              ],
            ),
          ),
        ).animate().fadeIn(duration: 300.ms, delay: (i * 30).ms);
      },
    );
  }

  Widget _buildList() {
    return ListView.separated(
      padding: const EdgeInsets.all(16),
      itemCount: _items.length,
      separatorBuilder: (_, __) => const SizedBox(height: 8),
      itemBuilder: (context, i) {
        final item = _items[i];
        return Container(
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(
            color: AppTheme.cardDark,
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: AppTheme.borderColor),
          ),
          child: Row(
            children: [
              Container(
                width: 40, height: 40,
                decoration: BoxDecoration(
                  color: AppTheme.vaultAccent.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Icon(
                  item.type == 'photo' ? Icons.image : Icons.description,
                  color: AppTheme.vaultAccent, size: 20,
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(item.name,
                      style: Theme.of(context).textTheme.bodyLarge,
                      maxLines: 1, overflow: TextOverflow.ellipsis),
                    Text(
                      '${item.createdAt.day}/${item.createdAt.month}/${item.createdAt.year}',
                      style: Theme.of(context).textTheme.bodyMedium,
                    ),
                  ],
                ),
              ),
              IconButton(
                icon: const Icon(Icons.delete_outline, color: AppTheme.dangerRed),
                onPressed: () => _deleteItem(item),
              ),
            ],
          ),
        ).animate().fadeIn(duration: 300.ms, delay: (i * 40).ms);
      },
    );
  }
}

// ── Internal data class ────────────────────────────────────────────
class _VaultEntry {
  final String id, type, encryptedPath, name;
  final DateTime createdAt;
  _VaultEntry({
    required this.id, required this.type, required this.encryptedPath,
    required this.name, required this.createdAt,
  });
}

// ── Source picker bottom sheet ─────────────────────────────────────
class _SourcePicker extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(24),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            width: 40, height: 4,
            decoration: BoxDecoration(
              color: AppTheme.borderColor,
              borderRadius: BorderRadius.circular(2),
            ),
          ),
          const SizedBox(height: 20),
          Text('اختر المصدر', style: Theme.of(context).textTheme.titleLarge),
          const SizedBox(height: 20),
          Row(
            children: [
              Expanded(child: _SourceOption(
                icon: Icons.photo_library, label: 'المعرض',
                onTap: () => Navigator.pop(context, ImageSource.gallery),
              )),
              const SizedBox(width: 16),
              Expanded(child: _SourceOption(
                icon: Icons.camera_alt, label: 'الكاميرا',
                onTap: () => Navigator.pop(context, ImageSource.camera),
              )),
            ],
          ),
          const SizedBox(height: 20),
        ],
      ),
    );
  }
}

class _SourceOption extends StatelessWidget {
  final IconData icon;
  final String label;
  final VoidCallback onTap;
  const _SourceOption({required this.icon, required this.label, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 20),
        decoration: BoxDecoration(
          color: AppTheme.cardDarker,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: AppTheme.borderColor),
        ),
        child: Column(
          children: [
            Icon(icon, color: AppTheme.vaultAccent, size: 32),
            const SizedBox(height: 8),
            Text(label, style: Theme.of(context).textTheme.bodyLarge),
          ],
        ),
      ),
    );
  }
}
