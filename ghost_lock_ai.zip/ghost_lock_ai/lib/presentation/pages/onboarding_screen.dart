import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../../core/constants/app_constants.dart';
import '../../core/theme/app_theme.dart';
import '../../core/utils/auth_service.dart';
import 'disguise_screen.dart';

class OnboardingScreen extends StatefulWidget {
  const OnboardingScreen({super.key});
  @override State<OnboardingScreen> createState() => _OnboardingScreenState();
}

class _OnboardingScreenState extends State<OnboardingScreen> {
  final PageController _pageCtrl = PageController();
  int _currentPage = 0;

  // Step 1 – disguise choice
  String _selectedDisguise = AppConstants.disguiseCalculator;

  // Step 2 – entry method
  String _selectedMethod = 'voice';

  // Step 3 – passphrase setup
  final _vaultPhraseCtrl = TextEditingController();
  final _devPhraseCtrl   = TextEditingController();
  final _decoyPhraseCtrl = TextEditingController();
  bool _showPhrases = false;

  // Tap-sequence setup state
  final List<int> _recordedTaps = [];

  bool get _canProceed {
    return switch (_currentPage) {
      0 => true,
      1 => true,
      2 => _vaultPhraseCtrl.text.trim().length >= 2,
      _ => true,
    };
  }

  void _next() {
    if (!_canProceed) return;
    if (_currentPage < 2) {
      _pageCtrl.nextPage(
        duration: const Duration(milliseconds: 400),
        curve: Curves.easeInOutCubic,
      );
    } else {
      _finishSetup();
    }
  }

  Future<void> _finishSetup() async {
    final vault = _vaultPhraseCtrl.text.trim();
    final dev   = _devPhraseCtrl.text.trim();
    final decoy = _decoyPhraseCtrl.text.trim();

    if (vault.isEmpty) return;

    await AuthService.setupPassphrases(
      vaultPhrase:     vault,
      developerPhrase: dev.isNotEmpty ? dev : null,
      decoyPhrase:     decoy.isNotEmpty ? decoy : null,
    );

    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(AppConstants.keyDisguiseMode, _selectedDisguise);
    await prefs.setString(AppConstants.keySecretMethod, _selectedMethod);
    await prefs.setBool(AppConstants.keySetupComplete, true);

    if (!mounted) return;
    Navigator.of(context).pushReplacement(
      MaterialPageRoute(builder: (_) => const DisguiseScreen()),
    );
  }

  @override
  void dispose() {
    _pageCtrl.dispose();
    _vaultPhraseCtrl.dispose();
    _devPhraseCtrl.dispose();
    _decoyPhraseCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.surfaceDark,
      body: SafeArea(
        child: Column(
          children: [
            _buildHeader(),
            Expanded(
              child: PageView(
                controller: _pageCtrl,
                physics: const NeverScrollableScrollPhysics(),
                onPageChanged: (i) => setState(() => _currentPage = i),
                children: [
                  _buildDisguisePage(),
                  _buildMethodPage(),
                  _buildPhrasePage(),
                ],
              ),
            ),
            _buildFooter(),
          ],
        ),
      ),
    );
  }

  Widget _buildHeader() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(24, 24, 24, 0),
      child: Column(
        children: [
          // Progress dots
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: List.generate(3, (i) {
              final active = i == _currentPage;
              final done   = i < _currentPage;
              return AnimatedContainer(
                duration: const Duration(milliseconds: 300),
                width: active ? 28 : 8,
                height: 8,
                margin: const EdgeInsets.symmetric(horizontal: 3),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(4),
                  color: done || active
                      ? AppTheme.vaultAccent
                      : AppTheme.borderColor,
                ),
              );
            }),
          ),
          const SizedBox(height: 20),
          // Ghost orb mini
          Container(
            width: 64, height: 64,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: AppTheme.cardDark,
              border: Border.all(color: AppTheme.vaultAccent.withOpacity(0.5), width: 1.5),
              boxShadow: [
                BoxShadow(
                  color: AppTheme.vaultAccent.withOpacity(0.2),
                  blurRadius: 20, spreadRadius: 2,
                ),
              ],
            ),
            child: const Icon(Icons.lock_outline, color: AppTheme.vaultAccent, size: 28),
          ),
          const SizedBox(height: 16),
          Text('Ghost Lock AI',
            style: Theme.of(context).textTheme.displayMedium),
          const SizedBox(height: 6),
          Text('إعداد الخزنة السرية',
            style: Theme.of(context).textTheme.bodyMedium),
        ],
      ),
    ).animate().fadeIn(duration: 600.ms).slideY(begin: -0.05);
  }

  // ── Page 1: Disguise ──────────────────────────────────────────
  Widget _buildDisguisePage() {
    final options = [
      (AppConstants.disguiseCalculator, 'آلة حاسبة', Icons.calculate_outlined,
        'يظهر كتطبيق حاسبة عادية'),
      (AppConstants.disguiseNotes, 'ملاحظات', Icons.sticky_note_2_outlined,
        'يظهر كتطبيق ملاحظات'),
      (AppConstants.disguiseWeather, 'طقس', Icons.wb_sunny_outlined,
        'يظهر كتطبيق أحوال الطقس'),
      (AppConstants.disguiseDiary, 'مفكرة', Icons.book_outlined,
        'يظهر كتطبيق يوميات'),
    ];

    return SingleChildScrollView(
      padding: const EdgeInsets.fromLTRB(24, 24, 24, 0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text('اختر تمويه التطبيق',
            style: Theme.of(context).textTheme.titleLarge),
          const SizedBox(height: 6),
          Text('سيظهر هذا الشكل عند فتح التطبيق',
            style: Theme.of(context).textTheme.bodyMedium),
          const SizedBox(height: 20),
          ...options.asMap().entries.map((e) {
            final opt      = e.value;
            final selected = _selectedDisguise == opt.$1;
            return GestureDetector(
              onTap: () => setState(() => _selectedDisguise = opt.$1),
              child: AnimatedContainer(
                duration: const Duration(milliseconds: 250),
                margin: const EdgeInsets.only(bottom: 12),
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: selected
                      ? AppTheme.vaultAccent.withOpacity(0.08)
                      : AppTheme.cardDark,
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(
                    color: selected ? AppTheme.vaultAccent : AppTheme.borderColor,
                    width: selected ? 1.5 : 1,
                  ),
                ),
                child: Row(
                  children: [
                    Container(
                      width: 48, height: 48,
                      decoration: BoxDecoration(
                        color: (selected
                            ? AppTheme.vaultAccent
                            : AppTheme.textMuted).withOpacity(0.1),
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: Icon(opt.$3,
                        color: selected ? AppTheme.vaultAccent : AppTheme.textMuted,
                        size: 24),
                    ),
                    const SizedBox(width: 14),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(opt.$2, style: Theme.of(context)
                            .textTheme.titleMedium?.copyWith(fontSize: 15)),
                          const SizedBox(height: 2),
                          Text(opt.$4, style: Theme.of(context).textTheme.bodyMedium),
                        ],
                      ),
                    ),
                    if (selected)
                      const Icon(Icons.check_circle,
                        color: AppTheme.vaultAccent, size: 22),
                  ],
                ),
              ).animate(key: ValueKey(opt.$1))
                .fadeIn(duration: 300.ms, delay: (e.key * 60).ms),
            );
          }),
        ],
      ),
    );
  }

  // ── Page 2: Entry Method ──────────────────────────────────────
  Widget _buildMethodPage() {
    final methods = [
      ('voice',   'بصمة الصوت',    Icons.mic_outlined,
        'انطق كلمة سر سرية للدخول — الأكثر أماناً'),
      ('tap',     'تسلسل النقر',   Icons.touch_app_outlined,
        'انقر على مناطق معينة بترتيب محدد'),
      ('pattern', 'نمط سري',       Icons.grid_view_outlined,
        'ارسم نمطاً غير مرئي على الشاشة'),
      ('swipe',   'حركات السحب',   Icons.swipe_outlined,
        'سلسلة من حركات السحب بالإصبع'),
    ];

    return SingleChildScrollView(
      padding: const EdgeInsets.fromLTRB(24, 24, 24, 0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text('طريقة الدخول السري',
            style: Theme.of(context).textTheme.titleLarge),
          const SizedBox(height: 6),
          Text('كيف ستفتح خزنتك؟',
            style: Theme.of(context).textTheme.bodyMedium),
          const SizedBox(height: 20),
          ...methods.asMap().entries.map((e) {
            final m        = e.value;
            final selected = _selectedMethod == m.$1;
            return GestureDetector(
              onTap: () => setState(() => _selectedMethod = m.$1),
              child: AnimatedContainer(
                duration: const Duration(milliseconds: 250),
                margin: const EdgeInsets.only(bottom: 12),
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: selected
                      ? AppTheme.vaultAccent.withOpacity(0.08)
                      : AppTheme.cardDark,
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(
                    color: selected ? AppTheme.vaultAccent : AppTheme.borderColor,
                    width: selected ? 1.5 : 1,
                  ),
                ),
                child: Row(
                  children: [
                    Container(
                      width: 48, height: 48,
                      decoration: BoxDecoration(
                        color: (selected
                            ? AppTheme.vaultAccent
                            : AppTheme.textMuted).withOpacity(0.1),
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: Icon(m.$3,
                        color: selected ? AppTheme.vaultAccent : AppTheme.textMuted,
                        size: 24),
                    ),
                    const SizedBox(width: 14),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(m.$2, style: Theme.of(context)
                            .textTheme.titleMedium?.copyWith(fontSize: 15)),
                          const SizedBox(height: 2),
                          Text(m.$4, style: Theme.of(context).textTheme.bodyMedium),
                        ],
                      ),
                    ),
                    if (selected)
                      const Icon(Icons.check_circle,
                        color: AppTheme.vaultAccent, size: 22),
                  ],
                ),
              ).animate().fadeIn(duration: 300.ms, delay: (e.key * 60).ms),
            );
          }),
        ],
      ),
    );
  }

  // ── Page 3: Passphrases ───────────────────────────────────────
  Widget _buildPhrasePage() {
    return SingleChildScrollView(
      padding: const EdgeInsets.fromLTRB(24, 24, 24, 0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text('كلمات السر السرية',
            style: Theme.of(context).textTheme.titleLarge),
          const SizedBox(height: 6),
          Text('يمكن استخدام كلمات مختلفة لفتح أقسام مختلفة',
            style: Theme.of(context).textTheme.bodyMedium),
          const SizedBox(height: 24),

          // Vault phrase (required)
          _PhraseField(
            controller: _vaultPhraseCtrl,
            label: 'كلمة الخزنة الرئيسية *',
            hint: 'مثال: محمد',
            icon: Icons.lock_outline,
            color: AppTheme.vaultAccent,
            showText: _showPhrases,
            onChanged: (_) => setState(() {}),
          ),
          const SizedBox(height: 8),
          _hintCard(
            'هذه الكلمة ستفتح خزنتك الرئيسية. لا تنساها أبداً.',
            AppTheme.vaultAccent,
          ),

          const SizedBox(height: 20),

          // Developer phrase (optional)
          _PhraseField(
            controller: _devPhraseCtrl,
            label: 'كلمة وضع المطور (اختياري)',
            hint: 'مثال: أحمد',
            icon: Icons.developer_mode,
            color: AppTheme.warningAmber,
            showText: _showPhrases,
          ),
          const SizedBox(height: 8),
          _hintCard(
            'تفتح لوحة تحكم خاصة بالإعدادات المتقدمة.',
            AppTheme.warningAmber,
          ),

          const SizedBox(height: 20),

          // Decoy phrase (optional)
          _PhraseField(
            controller: _decoyPhraseCtrl,
            label: 'كلمة الخزنة الوهمية (اختياري)',
            hint: 'مثال: علي',
            icon: Icons.visibility_off_outlined,
            color: AppTheme.dangerRed,
            showText: _showPhrases,
          ),
          const SizedBox(height: 8),
          _hintCard(
            'تفتح خزنة فارغة مزيفة عند الإكراه.',
            AppTheme.dangerRed,
          ),

          const SizedBox(height: 16),

          // Show/hide toggle
          Row(
            children: [
              Switch.adaptive(
                value: _showPhrases,
                onChanged: (v) => setState(() => _showPhrases = v),
                activeColor: AppTheme.vaultAccent,
              ),
              const SizedBox(width: 8),
              Text('إظهار النص', style: Theme.of(context).textTheme.bodyMedium),
            ],
          ),
          const SizedBox(height: 20),
        ],
      ),
    );
  }

  Widget _hintCard(String text, Color color) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
      decoration: BoxDecoration(
        color: color.withOpacity(0.06),
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: color.withOpacity(0.2)),
      ),
      child: Row(
        children: [
          Icon(Icons.info_outline, color: color, size: 16),
          const SizedBox(width: 8),
          Expanded(child: Text(text,
            style: TextStyle(color: color.withOpacity(0.85), fontSize: 12))),
        ],
      ),
    );
  }

  Widget _buildFooter() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(24, 12, 24, 28),
      child: Row(
        children: [
          if (_currentPage > 0)
            Expanded(
              child: OutlinedButton(
                onPressed: () => _pageCtrl.previousPage(
                  duration: const Duration(milliseconds: 400),
                  curve: Curves.easeInOutCubic,
                ),
                style: OutlinedButton.styleFrom(
                  side: const BorderSide(color: AppTheme.borderColor),
                  foregroundColor: AppTheme.textSecondary,
                  padding: const EdgeInsets.symmetric(vertical: 16),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(14)),
                ),
                child: const Text('السابق'),
              ),
            ),
          if (_currentPage > 0) const SizedBox(width: 12),
          Expanded(
            flex: 2,
            child: ElevatedButton(
              onPressed: _canProceed ? _next : null,
              style: ElevatedButton.styleFrom(
                backgroundColor: AppTheme.vaultAccent,
                foregroundColor: AppTheme.ghostBlue,
                disabledBackgroundColor: AppTheme.borderColor,
                padding: const EdgeInsets.symmetric(vertical: 16),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(14)),
                textStyle: const TextStyle(
                  fontSize: 15, fontWeight: FontWeight.w700),
              ),
              child: Text(_currentPage == 2 ? 'إنهاء الإعداد' : 'التالي'),
            ),
          ),
        ],
      ),
    ).animate().fadeIn(duration: 400.ms, delay: 200.ms);
  }
}

// ── Reusable phrase input field ────────────────────────────────────
class _PhraseField extends StatelessWidget {
  final TextEditingController controller;
  final String label, hint;
  final IconData icon;
  final Color color;
  final bool showText;
  final ValueChanged<String>? onChanged;

  const _PhraseField({
    required this.controller, required this.label, required this.hint,
    required this.icon, required this.color, required this.showText,
    this.onChanged,
  });

  @override
  Widget build(BuildContext context) {
    return TextField(
      controller: controller,
      obscureText: !showText,
      textDirection: TextDirection.rtl,
      style: const TextStyle(color: AppTheme.textPrimary, fontSize: 16),
      onChanged: onChanged,
      decoration: InputDecoration(
        labelText: label,
        hintText: hint,
        prefixIcon: Icon(icon, color: color, size: 20),
        labelStyle: TextStyle(color: color.withOpacity(0.8), fontSize: 13),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: BorderSide(color: color.withOpacity(0.3)),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: BorderSide(color: color, width: 1.5),
        ),
        filled: true,
        fillColor: AppTheme.cardDarker,
      ),
    );
  }
}
