import 'dart:async';
import 'dart:math';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:speech_to_text/speech_to_text.dart';
import '../../core/constants/app_constants.dart';
import '../../core/theme/app_theme.dart';
import '../../core/utils/auth_service.dart';
import 'vault_home_screen.dart';

class SecretEntryScreen extends StatefulWidget {
  const SecretEntryScreen({super.key});
  @override State<SecretEntryScreen> createState() => _SecretEntryScreenState();
}

class _SecretEntryScreenState extends State<SecretEntryScreen>
    with TickerProviderStateMixin {

  late AnimationController _pulseCtrl;
  late AnimationController _shakeCtrl;
  final SpeechToText _speech = SpeechToText();

  bool    _isListening  = false;
  bool    _isLoading    = false;
  bool    _isLocked     = false;
  String  _statusText   = 'انطق كلمة السر للدخول';
  String  _detectedText = '';
  int     _failCount    = 0;
  Duration _lockRemaining = Duration.zero;
  Timer?  _lockTimer;

  // Tap sequence state
  final List<int> _tapSequence = [];
  int _tapCount = 0;

  @override
  void initState() {
    super.initState();
    _pulseCtrl = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 2),
    )..repeat(reverse: true);
    _shakeCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 500),
    );
    _checkLockState();
  }

  void _checkLockState() {
    if (AuthService.isLocked) {
      setState(() {
        _isLocked = true;
        _lockRemaining = AuthService.remainingLockTime;
      });
      _startLockTimer();
    }
  }

  void _startLockTimer() {
    _lockTimer = Timer.periodic(const Duration(seconds: 1), (_) {
      if (!mounted) return;
      if (!AuthService.isLocked) {
        setState(() { _isLocked = false; _statusText = 'انطق كلمة السر للدخول'; });
        _lockTimer?.cancel();
      } else {
        setState(() { _lockRemaining = AuthService.remainingLockTime; });
      }
    });
  }

  // ── Voice Auth ─────────────────────────────────────────────────
  Future<void> _startVoiceAuth() async {
    if (_isLocked || _isLoading) return;
    HapticFeedback.mediumImpact();

    setState(() {
      _isListening  = true;
      _statusText   = 'أنا أسمعك...';
      _detectedText = '';
    });

    final result = await AuthService.authenticateByVoice();
    if (!mounted) return;
    _handleAuthResult(result);
  }

  void _handleAuthResult(AuthResult result) {
    setState(() { _isListening = false; _isLoading = false; });

    switch (result) {
      case AuthResult.vault:
        _onSuccess(AuthResult.vault);
        break;
      case AuthResult.developer:
        _onSuccess(AuthResult.developer);
        break;
      case AuthResult.decoy:
        _onSuccess(AuthResult.decoy);
        break;
      case AuthResult.locked:
        setState(() {
          _isLocked = true;
          _statusText = 'تم القفل بسبب محاولات فاشلة';
          _lockRemaining = AuthService.remainingLockTime;
        });
        _startLockTimer();
        break;
      case AuthResult.denied:
        _failCount++;
        setState(() {
          _statusText = 'كلمة سر خاطئة · ${AuthService.remainingAttempts} محاولات متبقية';
        });
        _shakeCtrl.forward(from: 0);
        HapticFeedback.heavyImpact();
        break;
    }
  }

  void _onSuccess(AuthResult mode) {
    HapticFeedback.lightImpact();
    setState(() { _statusText = '✓ مرحباً'; });
    Future.delayed(const Duration(milliseconds: 600), () {
      if (!mounted) return;
      Navigator.of(context).pushReplacement(
        PageRouteBuilder(
          pageBuilder: (_, __, ___) => VaultHomeScreen(entryMode: mode),
          transitionsBuilder: (_, anim, __, child) {
            return SlideTransition(
              position: Tween(
                begin: const Offset(0, 0.05),
                end: Offset.zero,
              ).animate(CurvedAnimation(parent: anim, curve: Curves.easeOutCubic)),
              child: FadeTransition(opacity: anim, child: child),
            );
          },
          transitionDuration: const Duration(milliseconds: 600),
        ),
      );
    });
  }

  // ── Tap Counter (secondary method) ────────────────────────────
  void _onOrb tap() {
    if (_isLocked) return;
    _tapCount++;
    _tapSequence.add(_tapCount);
    HapticFeedback.selectionClick();

    if (_tapSequence.length >= AppConstants.tapSequenceLength) {
      // Check against stored sequence
      AuthService.authenticateByTaps(_tapSequence).then(_handleAuthResult);
      _tapSequence.clear();
      _tapCount = 0;
    }
  }

  @override
  void dispose() {
    _pulseCtrl.dispose();
    _shakeCtrl.dispose();
    _lockTimer?.cancel();
    _speech.stop();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.surfaceDark,
      body: AnnotatedRegion<SystemUiOverlayStyle>(
        value: SystemUiOverlayStyle.light,
        child: SafeArea(
          child: Stack(
            children: [
              _buildBackground(),
              _buildContent(),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildBackground() {
    return AnimatedBuilder(
      animation: _pulseCtrl,
      builder: (_, __) {
        return CustomPaint(
          size: MediaQuery.of(context).size,
          painter: _ParticlePainter(_pulseCtrl.value),
        );
      },
    );
  }

  Widget _buildContent() {
    return Column(
      children: [
        const Spacer(flex: 2),
        // Ghost Lock logo / orb
        _buildGhostOrb(),
        const SizedBox(height: 40),
        // Status text
        _buildStatusSection(),
        const Spacer(flex: 3),
        // Bottom controls
        _buildBottomControls(),
        const SizedBox(height: 40),
      ],
    );
  }

  Widget _buildGhostOrb() {
    return AnimatedBuilder(
      animation: _pulseCtrl,
      builder: (_, child) {
        final scale = 1.0 + (_pulseCtrl.value * 0.06);
        final glow  = _isListening ? 0.8 : 0.3 + (_pulseCtrl.value * 0.2);
        return GestureDetector(
          onTap: _startVoiceAuth,
          child: Transform.scale(
            scale: scale,
            child: Container(
              width: 140,
              height: 140,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: AppTheme.cardDark,
                border: Border.all(
                  color: AppTheme.vaultAccent.withOpacity(0.4 + _pulseCtrl.value * 0.3),
                  width: 2,
                ),
                boxShadow: [
                  BoxShadow(
                    color: AppTheme.vaultAccent.withOpacity(glow * 0.5),
                    blurRadius: 40 + _pulseCtrl.value * 20,
                    spreadRadius: 5,
                  ),
                ],
              ),
              child: _isListening
                  ? _buildWaveform()
                  : Icon(
                      Icons.lock_outline,
                      size: 52,
                      color: AppTheme.vaultAccent,
                    ),
            ),
          ),
        );
      },
    );
  }

  Widget _buildWaveform() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      crossAxisAlignment: CrossAxisAlignment.center,
      children: List.generate(5, (i) {
        return AnimatedBuilder(
          animation: _pulseCtrl,
          builder: (_, __) {
            final height = 20.0 + sin((_pulseCtrl.value * 2 * pi) + i * 0.8) * 18;
            return Container(
              width: 5,
              height: height,
              margin: const EdgeInsets.symmetric(horizontal: 3),
              decoration: BoxDecoration(
                color: AppTheme.vaultAccent,
                borderRadius: BorderRadius.circular(3),
              ),
            );
          },
        );
      }),
    );
  }

  Widget _buildStatusSection() {
    return AnimatedBuilder(
      animation: _shakeCtrl,
      builder: (_, child) {
        final dx = sin(_shakeCtrl.value * 6 * pi) * 12 * (1 - _shakeCtrl.value);
        return Transform.translate(
          offset: Offset(dx, 0),
          child: child,
        );
      },
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 40),
        child: Column(
          children: [
            if (_isLocked) ...[
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
                decoration: BoxDecoration(
                  color: AppTheme.dangerRed.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: AppTheme.dangerRed.withOpacity(0.3)),
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const Icon(Icons.timer, color: AppTheme.dangerRed, size: 18),
                    const SizedBox(width: 8),
                    Text(
                      'مغلق · ${_lockRemaining.inMinutes}:${(_lockRemaining.inSeconds % 60).toString().padLeft(2, '0')}',
                      style: TextStyle(
                        color: AppTheme.dangerRed,
                        fontSize: 15,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ],
                ),
              ),
            ] else ...[
              Text(
                _statusText,
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: _failCount > 0 ? AppTheme.dangerRed : AppTheme.textSecondary,
                  fontSize: 15,
                ),
              ),
            ],
            if (_detectedText.isNotEmpty) ...[
              const SizedBox(height: 12),
              Text(
                '"$_detectedText"',
                style: const TextStyle(
                  color: AppTheme.textMuted,
                  fontSize: 13,
                  fontStyle: FontStyle.italic,
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }

  Widget _buildBottomControls() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 40),
      child: Column(
        children: [
          // Voice button
          SizedBox(
            width: double.infinity,
            child: ElevatedButton.icon(
              onPressed: _isLocked ? null : _startVoiceAuth,
              icon: Icon(_isListening ? Icons.mic : Icons.mic_none),
              label: Text(_isListening ? 'جارٍ الاستماع...' : 'انطق كلمة السر'),
              style: ElevatedButton.styleFrom(
                backgroundColor: _isListening
                    ? AppTheme.dangerRed
                    : AppTheme.vaultAccent,
                foregroundColor: AppTheme.ghostBlue,
                padding: const EdgeInsets.symmetric(vertical: 16),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(14),
                ),
              ),
            ),
          ),
          const SizedBox(height: 12),
          // Divider with "أو"
          Row(
            children: [
              const Expanded(child: Divider(color: AppTheme.borderColor)),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 12),
                child: Text('أو', style: TextStyle(color: AppTheme.textMuted)),
              ),
              const Expanded(child: Divider(color: AppTheme.borderColor)),
            ],
          ),
          const SizedBox(height: 12),
          // Tap sequence
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text('طريقة النقر السرية',
                style: TextStyle(color: AppTheme.textMuted, fontSize: 13)),
            ],
          ),
          const SizedBox(height: 12),
          // Tap dots display
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: List.generate(AppConstants.tapSequenceLength, (i) {
              return Container(
                width: 10, height: 10,
                margin: const EdgeInsets.symmetric(horizontal: 4),
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: i < _tapSequence.length
                      ? AppTheme.vaultAccent
                      : AppTheme.borderColor,
                ),
              );
            }),
          ),
          const SizedBox(height: 12),
          // Secret tap zones — 4 invisible buttons in a row
          Opacity(
            opacity: 0.0, // invisible — the user knows where to tap
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: List.generate(4, (i) => GestureDetector(
                onTap: () {
                  _tapSequence.add(i);
                  HapticFeedback.selectionClick();
                  if (_tapSequence.length >= AppConstants.tapSequenceLength) {
                    AuthService.authenticateByTaps(
                      List<int>.from(_tapSequence),
                    ).then(_handleAuthResult);
                    _tapSequence.clear();
                  }
                  setState(() {});
                },
                child: Container(
                  width: 60, height: 60,
                  color: Colors.transparent,
                ),
              )),
            ),
          ),
        ],
      ),
    ).animate().fadeIn(duration: 600.ms, delay: 300.ms).slideY(begin: 0.1);
  }
}

// ── Ambient Particle Background ────────────────────────────────────
class _ParticlePainter extends CustomPainter {
  final double progress;
  static final List<Map<String, double>> _particles = List.generate(30, (_) {
    final r = Random();
    return {
      'x': r.nextDouble(), 'y': r.nextDouble(),
      'size': 1.0 + r.nextDouble() * 2.5,
      'speed': 0.2 + r.nextDouble() * 0.8,
      'phase': r.nextDouble(),
    };
  });

  _ParticlePainter(this.progress);

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()..style = PaintingStyle.fill;
    for (final p in _particles) {
      final x = (p['x']! * size.width + sin(progress * 2 * pi * p['speed']! + p['phase']! * pi) * 15) % size.width;
      final y = (p['y']! * size.height + cos(progress * 2 * pi * p['speed']! * 0.7 + p['phase']! * pi) * 10) % size.height;
      paint.color = const Color(0xFF00D4FF).withOpacity(0.04 + p['size']! * 0.015);
      canvas.drawCircle(Offset(x, y), p['size']!, paint);
    }
  }

  @override
  bool shouldRepaint(_ParticlePainter old) => old.progress != progress;
}
