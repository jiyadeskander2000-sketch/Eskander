import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';
import 'package:file_picker/file_picker.dart';
import '../../core/theme/app_theme.dart';
import '../../core/utils/encryption_service.dart';
import '../../data/datasources/vault_database.dart';

class BackupScreen extends StatefulWidget {
  const BackupScreen({super.key});
  @override State<BackupScreen> createState() => _BackupScreenState();
}

class _BackupScreenState extends State<BackupScreen> {
  bool _isExporting = false;
  bool _isImporting = false;
  String? _lastBackupDate;

  @override
  void initState() {
    super.initState();
    _loadLastBackupDate();
  }

  Future<void> _loadLastBackupDate() async {
    // Load from preferences
    setState(() => _lastBackupDate = 'لا يوجد نسخ احتياطي سابق');
  }

  Future<void> _exportLocalBackup() async {
    setState(() => _isExporting = true);
    try {
      // 1. Fetch all data from DB
      final notes   = await VaultDatabase.getNotes();
      final folders = await VaultDatabase.getFolders();
      final stats   = await VaultDatabase.getVaultStats();

      final payload = {
        'version':    1,
        'exportedAt': DateTime.now().toIso8601String(),
        'stats':      stats,
        'folderCount': folders.length,
        'noteCount':   notes.length,
        'notesMeta':  notes.map((n) => {
          'id': n.id, 'title': n.title,
          'createdAt': n.createdAt.toIso8601String(),
        }).toList(),
      };

      // 2. Encrypt the metadata
      final json      = jsonEncode(payload);
      final encrypted = await EncryptionService.encryptText(json);

      // 3. Write to file
      final dir  = await getTemporaryDirectory();
      final file = File('${dir.path}/ghost_lock_backup_${DateTime.now().millisecondsSinceEpoch}.glb');
      await file.writeAsString(encrypted);

      // 4. Share
      await Share.shareXFiles(
        [XFile(file.path)],
        subject: 'Ghost Lock AI — نسخة احتياطية',
      );

      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
          content: Text('تم تصدير النسخة الاحتياطية بنجاح'),
          backgroundColor: AppTheme.successGreen,
          behavior: SnackBarBehavior.floating,
        ));
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(
          content: Text('خطأ في التصدير: $e'),
          backgroundColor: AppTheme.dangerRed,
          behavior: SnackBarBehavior.floating,
        ));
      }
    } finally {
      setState(() => _isExporting = false);
    }
  }

  Future<void> _importLocalBackup() async {
    setState(() => _isImporting = true);
    try {
      final result = await FilePicker.platform.pickFiles(
        type: FileType.custom, allowedExtensions: ['glb'],
      );
      if (result == null || result.files.single.path == null) {
        setState(() => _isImporting = false);
        return;
      }

      final file      = File(result.files.single.path!);
      final encrypted = await file.readAsString();
      final json      = await EncryptionService.decryptText(encrypted);
      final payload   = jsonDecode(json) as Map<String, dynamic>;

      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(
          content: Text(
            'تم استيراد النسخة الاحتياطية\n'
            '${payload['noteCount']} ملاحظة، ${payload['folderCount']} مجلد',
          ),
          backgroundColor: AppTheme.successGreen,
          behavior: SnackBarBehavior.floating,
        ));
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(
          content: Text('ملف غير صحيح أو تالف: $e'),
          backgroundColor: AppTheme.dangerRed,
          behavior: SnackBarBehavior.floating,
        ));
      }
    } finally {
      setState(() => _isImporting = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.surfaceDark,
      appBar: AppBar(title: const Text('النسخ الاحتياطي والاستعادة')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          // Status card
          _buildStatusCard(),
          const SizedBox(height: 24),

          // Local backup
          _sectionLabel('النسخ الاحتياطي المحلي'),
          const SizedBox(height: 12),
          _buildActionCard(
            icon: Icons.download_outlined,
            color: AppTheme.vaultAccent,
            title: 'تصدير نسخة احتياطية',
            subtitle: 'حفظ ملف مشفر على جهازك أو مشاركته',
            isLoading: _isExporting,
            onTap: _exportLocalBackup,
          ),
          const SizedBox(height: 10),
          _buildActionCard(
            icon: Icons.upload_outlined,
            color: AppTheme.successGreen,
            title: 'استيراد نسخة احتياطية',
            subtitle: 'استعادة البيانات من ملف .glb مشفر',
            isLoading: _isImporting,
            onTap: _importLocalBackup,
          ),

          const SizedBox(height: 24),

          // Cloud (Firebase)
          _sectionLabel('النسخ السحابي (Firebase)'),
          const SizedBox(height: 12),
          _buildActionCard(
            icon: Icons.cloud_upload_outlined,
            color: AppTheme.warningAmber,
            title: 'رفع إلى السحابة',
            subtitle: 'مزامنة مشفرة مع Firebase — يتطلب تسجيل دخول',
            isLoading: false,
            onTap: () => _showFirebaseNotice(),
          ),
          const SizedBox(height: 10),
          _buildActionCard(
            icon: Icons.cloud_download_outlined,
            color: AppTheme.textSecondary,
            title: 'تنزيل من السحابة',
            subtitle: 'استعادة آخر نسخة من Firebase',
            isLoading: false,
            onTap: () => _showFirebaseNotice(),
          ),

          const SizedBox(height: 24),
          _buildWarningCard(),
          const SizedBox(height: 80),
        ],
      ),
    );
  }

  Widget _sectionLabel(String label) => Padding(
    padding: const EdgeInsets.only(right: 4),
    child: Text(label.toUpperCase(),
      style: const TextStyle(
        color: AppTheme.textMuted, fontSize: 11,
        fontWeight: FontWeight.w600, letterSpacing: 1,
      )),
  );

  Widget _buildStatusCard() {
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: AppTheme.cardDark,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppTheme.borderColor),
      ),
      child: Row(
        children: [
          Container(
            width: 48, height: 48,
            decoration: BoxDecoration(
              color: AppTheme.vaultAccent.withOpacity(0.1),
              borderRadius: BorderRadius.circular(12),
            ),
            child: const Icon(Icons.backup, color: AppTheme.vaultAccent, size: 24),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('آخر نسخة احتياطية',
                  style: Theme.of(context).textTheme.titleMedium?.copyWith(fontSize: 14)),
                const SizedBox(height: 3),
                Text(_lastBackupDate ?? 'لا يوجد',
                  style: Theme.of(context).textTheme.bodyMedium),
              ],
            ),
          ),
        ],
      ),
    ).animate().fadeIn(duration: 400.ms);
  }

  Widget _buildActionCard({
    required IconData icon, required Color color,
    required String title, required String subtitle,
    required bool isLoading, required VoidCallback onTap,
  }) {
    return GestureDetector(
      onTap: isLoading ? null : onTap,
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: AppTheme.cardDark,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: AppTheme.borderColor),
        ),
        child: Row(
          children: [
            Container(
              width: 44, height: 44,
              decoration: BoxDecoration(
                color: color.withOpacity(0.1),
                borderRadius: BorderRadius.circular(11),
              ),
              child: isLoading
                  ? Padding(
                      padding: const EdgeInsets.all(10),
                      child: CircularProgressIndicator(
                        color: color, strokeWidth: 2))
                  : Icon(icon, color: color, size: 22),
            ),
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(title, style: Theme.of(context).textTheme.bodyLarge?.copyWith(
                    fontWeight: FontWeight.w600)),
                  const SizedBox(height: 2),
                  Text(subtitle, style: Theme.of(context).textTheme.bodyMedium),
                ],
              ),
            ),
            Icon(Icons.arrow_forward_ios, size: 14, color: AppTheme.textMuted),
          ],
        ),
      ),
    );
  }

  Widget _buildWarningCard() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppTheme.warningAmber.withOpacity(0.06),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: AppTheme.warningAmber.withOpacity(0.2)),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Icon(Icons.warning_amber, color: AppTheme.warningAmber, size: 20),
          const SizedBox(width: 12),
          Expanded(
            child: Text(
              'النسخة الاحتياطية مشفرة بمفتاح خاص بجهازك. '
              'لا يمكن فتحها على جهاز آخر دون نقل المفتاح أيضاً.',
              style: TextStyle(
                color: AppTheme.warningAmber.withOpacity(0.85), fontSize: 12),
            ),
          ),
        ],
      ),
    );
  }

  void _showFirebaseNotice() {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: AppTheme.cardDark,
        title: const Text('Firebase غير مُعدّ',
          style: TextStyle(color: AppTheme.textPrimary)),
        content: const Text(
          'للتفعيل، أضف google-services.json من Firebase Console '
          'إلى مجلد android/app وفعّل Firebase Authentication.',
          style: TextStyle(color: AppTheme.textSecondary)),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('موافق', style: TextStyle(color: AppTheme.vaultAccent)),
          ),
        ],
      ),
    );
  }
}
