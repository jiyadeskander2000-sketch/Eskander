import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_animate/flutter_animate.dart';
import '../../core/constants/app_constants.dart';
import '../../core/theme/app_theme.dart';
import '../../core/utils/auth_service.dart';
import 'vault_section_screen.dart';
import 'secure_notes_screen.dart';
import 'attempts_log_screen.dart';
import 'settings_screen.dart';

class VaultHomeScreen extends StatefulWidget {
  final AuthResult entryMode;
  const VaultHomeScreen({super.key, required this.entryMode});
  @override State<VaultHomeScreen> createState() => _VaultHomeScreenState();
}

class _VaultHomeScreenState extends State<VaultHomeScreen> {
  int _selectedIndex = 0;

  // Stats (mock — fetched from DB in real implementation)
  int _photoCount = 0, _videoCount = 0, _fileCount = 0, _noteCount = 0;

  @override
  void initState() {
    super.initState();
    _blockScreenshot();
    _loadStats();
  }

  void _blockScreenshot() {
    // Prevent screenshots inside vault
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.immersiveSticky);
  }

  Future<void> _loadStats() async {
    // TODO: load from DB
    setState(() {
      _photoCount = 12; _videoCount = 3;
      _fileCount  = 7;  _noteCount  = 5;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.surfaceDark,
      body: SafeArea(
        child: IndexedStack(
          index: _selectedIndex,
          children: [
            _buildDashboard(),
            const VaultSectionScreen(type: AppConstants.sectionPhotos),
            const VaultSectionScreen(type: AppConstants.sectionFiles),
            const SecureNotesScreen(),
            const SettingsScreen(),
          ],
        ),
      ),
      bottomNavigationBar: _buildNavBar(),
    );
  }

  Widget _buildNavBar() {
    const items = [
      (Icons.dashboard_outlined, Icons.dashboard, 'الرئيسية'),
      (Icons.photo_library_outlined, Icons.photo_library, 'الصور'),
      (Icons.folder_outlined, Icons.folder, 'الملفات'),
      (Icons.sticky_note_2_outlined, Icons.sticky_note_2, 'الملاحظات'),
      (Icons.settings_outlined, Icons.settings, 'الإعدادات'),
    ];
    return Container(
      decoration: BoxDecoration(
        color: AppTheme.cardDark,
        border: Border(top: BorderSide(color: AppTheme.borderColor, width: 1)),
      ),
      child: Row(
        children: items.asMap().entries.map((e) {
          final selected = _selectedIndex == e.key;
          return Expanded(
            child: GestureDetector(
              onTap: () => setState(() => _selectedIndex = e.key),
              behavior: HitTestBehavior.opaque,
              child: Padding(
                padding: const EdgeInsets.symmetric(vertical: 10),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(
                      selected ? e.value.$2 : e.value.$1,
                      color: selected ? AppTheme.vaultAccent : AppTheme.textMuted,
                      size: 22,
                    ),
                    const SizedBox(height: 3),
                    Text(
                      e.value.$3,
                      style: TextStyle(
                        color: selected ? AppTheme.vaultAccent : AppTheme.textMuted,
                        fontSize: 10,
                        fontWeight: selected ? FontWeight.w600 : FontWeight.w400,
                      ),
                    ),
                    if (selected)
                      Container(
                        width: 4, height: 4,
                        margin: const EdgeInsets.only(top: 3),
                        decoration: const BoxDecoration(
                          shape: BoxShape.circle, color: AppTheme.vaultAccent,
                        ),
                      ),
                  ],
                ),
              ),
            ),
          );
        }).toList(),
      ),
    );
  }

  Widget _buildDashboard() {
    return CustomScrollView(
      slivers: [
        // App Bar
        SliverToBoxAdapter(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(20, 20, 20, 0),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('Ghost Lock',
                      style: Theme.of(context).textTheme.displayMedium,
                    ),
                    Text('خزنتك الآمنة',
                      style: Theme.of(context).textTheme.bodyMedium,
                    ),
                  ],
                ),
                GestureDetector(
                  onTap: () => Navigator.of(context).push(
                    MaterialPageRoute(builder: (_) => const AttemptsLogScreen()),
                  ),
                  child: Container(
                    width: 44, height: 44,
                    decoration: BoxDecoration(
                      color: AppTheme.cardDark,
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(color: AppTheme.borderColor),
                    ),
                    child: const Icon(Icons.security, color: AppTheme.vaultAccent),
                  ),
                ),
              ],
            ),
          ).animate().fadeIn(duration: 500.ms).slideX(begin: -0.05),
        ),

        const SliverToBoxAdapter(child: SizedBox(height: 24)),

        // Security badge
        SliverToBoxAdapter(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20),
            child: _buildSecurityBadge(),
          ).animate().fadeIn(delay: 100.ms, duration: 500.ms),
        ),

        const SliverToBoxAdapter(child: SizedBox(height: 20)),

        // Stats row
        SliverToBoxAdapter(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20),
            child: Row(
              children: [
                _buildStatCard('الصور', _photoCount, Icons.photo_library, AppTheme.vaultAccent),
                const SizedBox(width: 12),
                _buildStatCard('الفيديوهات', _videoCount, Icons.videocam, AppTheme.successGreen),
                const SizedBox(width: 12),
                _buildStatCard('الملفات', _fileCount, Icons.folder, AppTheme.warningAmber),
                const SizedBox(width: 12),
                _buildStatCard('الملاحظات', _noteCount, Icons.sticky_note_2, AppTheme.dangerRed),
              ],
            ),
          ).animate().fadeIn(delay: 200.ms, duration: 500.ms),
        ),

        const SliverToBoxAdapter(child: SizedBox(height: 24)),

        // Quick access section title
        SliverToBoxAdapter(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20),
            child: Text('وصول سريع',
              style: Theme.of(context).textTheme.titleMedium),
          ).animate().fadeIn(delay: 300.ms),
        ),

        const SliverToBoxAdapter(child: SizedBox(height: 12)),

        // Quick access grid
        SliverPadding(
          padding: const EdgeInsets.symmetric(horizontal: 20),
          sliver: SliverGrid(
            delegate: SliverChildListDelegate([
              _buildQuickTile('الصور والفيديو', Icons.photo_library_outlined,
                AppTheme.vaultAccent, () => setState(() => _selectedIndex = 1)),
              _buildQuickTile('الملفات المخفية', Icons.folder_outlined,
                AppTheme.warningAmber, () => setState(() => _selectedIndex = 2)),
              _buildQuickTile('الملاحظات السرية', Icons.sticky_note_2_outlined,
                AppTheme.successGreen, () => setState(() => _selectedIndex = 3)),
              _buildQuickTile('سجل المحاولات', Icons.history,
                AppTheme.dangerRed, () => Navigator.of(context).push(
                  MaterialPageRoute(builder: (_) => const AttemptsLogScreen()),
                )),
            ]),
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 2,
              childAspectRatio: 1.4,
              crossAxisSpacing: 12,
              mainAxisSpacing: 12,
            ),
          ),
        ),

        const SliverToBoxAdapter(child: SizedBox(height: 100)),
      ],
    );
  }

  Widget _buildSecurityBadge() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppTheme.vaultAccent.withOpacity(0.05),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppTheme.vaultAccent.withOpacity(0.2)),
        gradient: LinearGradient(
          colors: [
            AppTheme.vaultAccent.withOpacity(0.08),
            AppTheme.cardDark,
          ],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
      ),
      child: Row(
        children: [
          Container(
            width: 44, height: 44,
            decoration: BoxDecoration(
              color: AppTheme.vaultAccent.withOpacity(0.1),
              borderRadius: BorderRadius.circular(12),
            ),
            child: const Icon(Icons.verified_user, color: AppTheme.vaultAccent, size: 22),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('الخزنة محمية', style: TextStyle(
                  color: AppTheme.vaultAccent,
                  fontWeight: FontWeight.w700, fontSize: 14,
                )),
                Text('تشفير AES-256 · كل البيانات آمنة',
                  style: Theme.of(context).textTheme.bodyMedium?.copyWith(fontSize: 12)),
              ],
            ),
          ),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
            decoration: BoxDecoration(
              color: AppTheme.successGreen.withOpacity(0.1),
              borderRadius: BorderRadius.circular(20),
            ),
            child: const Text('آمن', style: TextStyle(
              color: AppTheme.successGreen, fontSize: 12, fontWeight: FontWeight.w600,
            )),
          ),
        ],
      ),
    );
  }

  Widget _buildStatCard(String label, int count, IconData icon, Color color) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 8),
        decoration: BoxDecoration(
          color: color.withOpacity(0.06),
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: color.withOpacity(0.2)),
        ),
        child: Column(
          children: [
            Icon(icon, color: color, size: 22),
            const SizedBox(height: 6),
            Text('$count', style: TextStyle(
              color: color, fontSize: 20, fontWeight: FontWeight.w700,
            )),
            Text(label, style: const TextStyle(
              color: AppTheme.textMuted, fontSize: 9,
            ), textAlign: TextAlign.center),
          ],
        ),
      ),
    );
  }

  Widget _buildQuickTile(String label, IconData icon, Color color, VoidCallback onTap) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        decoration: BoxDecoration(
          color: AppTheme.cardDark,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: AppTheme.borderColor),
        ),
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Container(
                width: 40, height: 40,
                decoration: BoxDecoration(
                  color: color.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Icon(icon, color: color, size: 20),
              ),
              Text(label, style: Theme.of(context).textTheme.titleMedium?.copyWith(
                fontSize: 13,
              )),
            ],
          ),
        ),
      ),
    );
  }
}
