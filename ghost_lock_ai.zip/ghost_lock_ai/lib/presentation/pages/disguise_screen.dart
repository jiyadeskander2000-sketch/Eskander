import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../../core/constants/app_constants.dart';
import '../../core/theme/app_theme.dart';
import 'secret_entry_screen.dart';

// ── Disguise Router ────────────────────────────────────────────────
class DisguiseScreen extends StatefulWidget {
  const DisguiseScreen({super.key});
  @override State<DisguiseScreen> createState() => _DisguiseScreenState();
}

class _DisguiseScreenState extends State<DisguiseScreen> {
  String _disguiseMode = AppConstants.disguiseCalculator;

  @override
  void initState() {
    super.initState();
    _loadMode();
  }

  Future<void> _loadMode() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      _disguiseMode = prefs.getString(AppConstants.keyDisguiseMode)
          ?? AppConstants.disguiseCalculator;
    });
  }

  @override
  Widget build(BuildContext context) {
    return switch (_disguiseMode) {
      AppConstants.disguiseCalculator => const CalculatorDisguise(),
      AppConstants.disguiseNotes      => const NotesDisguise(),
      AppConstants.disguiseWeather    => const WeatherDisguise(),
      AppConstants.disguiseDiary      => const DiaryDisguise(),
      _                               => const CalculatorDisguise(),
    };
  }
}

// ═══════════════════════════════════════════════════════════════════
//  CALCULATOR DISGUISE
// ═══════════════════════════════════════════════════════════════════
class CalculatorDisguise extends StatefulWidget {
  const CalculatorDisguise({super.key});
  @override State<CalculatorDisguise> createState() => _CalculatorDisguiseState();
}

class _CalculatorDisguiseState extends State<CalculatorDisguise> {
  String _display  = '0';
  String _history  = '';
  List<String> _taps = [];

  // Secret tap sequence: press "." five times then "="
  static const List<String> _secretSequence = ['.', '.', '.', '.', '.', '='];

  void _onButton(String val) {
    setState(() {
      if (val == 'C') {
        _display = '0'; _history = ''; _taps.clear();
      } else if (val == '⌫') {
        _display = _display.length > 1 ? _display.substring(0, _display.length - 1) : '0';
      } else if (val == '=') {
        _taps.add('=');
        _checkSecret();
        _history = _display;
        _display = _evaluateExpression(_display);
      } else if (val == '.') {
        _taps.add('.');
        _checkSecret();
        if (!_display.contains('.')) _display += '.';
      } else if (['+', '-', '×', '÷'].contains(val)) {
        _display += ' $val ';
      } else {
        _display = _display == '0' ? val : _display + val;
      }
    });
  }

  void _checkSecret() {
    if (_taps.length > _secretSequence.length) {
      _taps.removeAt(0);
    }
    if (_taps.length == _secretSequence.length &&
        _taps.join() == _secretSequence.join()) {
      _taps.clear();
      _navigateToVault();
    }
  }

  String _evaluateExpression(String expr) {
    try {
      // Simple eval — replace × and ÷
      final e = expr.replaceAll('×', '*').replaceAll('÷', '/');
      // Use dart's basic math (no eval, just simple single ops)
      if (e.contains(' + ')) {
        final p = e.split(' + ');
        return (double.parse(p[0]) + double.parse(p[1])).toStringAsFixed(2).replaceAll(RegExp(r'\.?0+$'), '');
      }
      if (e.contains(' - ')) {
        final p = e.split(' - ');
        return (double.parse(p[0]) - double.parse(p[1])).toStringAsFixed(2).replaceAll(RegExp(r'\.?0+$'), '');
      }
      if (e.contains(' * ')) {
        final p = e.split(' * ');
        return (double.parse(p[0]) * double.parse(p[1])).toStringAsFixed(2).replaceAll(RegExp(r'\.?0+$'), '');
      }
      if (e.contains(' / ')) {
        final p = e.split(' / ');
        final divisor = double.parse(p[1]);
        if (divisor == 0) return 'Error';
        return (double.parse(p[0]) / divisor).toStringAsFixed(2).replaceAll(RegExp(r'\.?0+$'), '');
      }
      return expr;
    } catch (_) {
      return 'Error';
    }
  }

  void _navigateToVault() {
    HapticFeedback.mediumImpact();
    Navigator.of(context).pushReplacement(
      PageRouteBuilder(
        pageBuilder: (_, __, ___) => const SecretEntryScreen(),
        transitionsBuilder: (_, anim, __, child) =>
            FadeTransition(opacity: anim, child: child),
        transitionDuration: const Duration(milliseconds: 500),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    SystemChrome.setSystemUIOverlayStyle(SystemUiOverlayStyle.light);
    return Scaffold(
      backgroundColor: const Color(0xFF1C1C1E),
      body: SafeArea(
        child: Column(
          children: [
            // Display
            Expanded(
              flex: 2,
              child: Container(
                alignment: Alignment.bottomRight,
                padding: const EdgeInsets.all(24),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.end,
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    if (_history.isNotEmpty)
                      Text(_history,
                        style: const TextStyle(
                          color: Color(0xFF8E8E93), fontSize: 20,
                        ),
                      ),
                    const SizedBox(height: 8),
                    Text(
                      _display,
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: _display.length > 9 ? 36 : 56,
                        fontWeight: FontWeight.w200,
                        letterSpacing: -1,
                      ),
                    ),
                  ],
                ),
              ),
            ),
            // Buttons grid
            Expanded(
              flex: 3,
              child: Padding(
                padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
                child: Column(
                  children: [
                    _buildRow(['C', '+/-', '%', '÷']),
                    _buildRow(['7', '8', '9', '×']),
                    _buildRow(['4', '5', '6', '-']),
                    _buildRow(['1', '2', '3', '+']),
                    _buildRow(['0', '.', '⌫', '=']),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildRow(List<String> buttons) {
    return Expanded(
      child: Row(
        children: buttons.map((b) => Expanded(child: _CalcButton(
          label: b, onTap: () => _onButton(b),
        ))).toList(),
      ),
    );
  }
}

class _CalcButton extends StatelessWidget {
  final String label;
  final VoidCallback onTap;
  const _CalcButton({required this.label, required this.onTap});

  Color get _bg {
    if (['C', '+/-', '%'].contains(label)) return const Color(0xFFA5A5A5);
    if (['÷', '×', '-', '+', '='].contains(label)) return const Color(0xFFFF9F0A);
    return const Color(0xFF333333);
  }
  Color get _fg {
    if (['C', '+/-', '%'].contains(label)) return Colors.black;
    return Colors.white;
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(4),
      child: Material(
        color: _bg,
        shape: const CircleBorder(),
        clipBehavior: Clip.antiAlias,
        child: InkWell(
          onTap: () { HapticFeedback.selectionClick(); onTap(); },
          child: AspectRatio(
            aspectRatio: label == '0' ? 0.5 : 1,
            child: Center(
              child: Text(label,
                style: TextStyle(
                  color: _fg,
                  fontSize: 22,
                  fontWeight: FontWeight.w400,
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════
//  NOTES DISGUISE
// ═══════════════════════════════════════════════════════════════════
class NotesDisguise extends StatefulWidget {
  const NotesDisguise({super.key});
  @override State<NotesDisguise> createState() => _NotesDisguiseState();
}

class _NotesDisguiseState extends State<NotesDisguise> {
  int _titleTaps = 0;
  DateTime? _lastTap;

  final List<Map<String, String>> _fakeNotes = [
    {'title': 'قائمة التسوق', 'preview': 'حليب، خبز، بيض...', 'date': 'اليوم'},
    {'title': 'أفكار عمل', 'preview': 'مشروع جديد، اجتماع الاثنين...', 'date': 'أمس'},
    {'title': 'مواعيد مهمة', 'preview': 'طبيب الأسنان 3 يناير...', 'date': '2 يناير'},
  ];

  void _onTitleTap() {
    final now = DateTime.now();
    if (_lastTap != null && now.difference(_lastTap!) > const Duration(seconds: 2)) {
      _titleTaps = 0;
    }
    _lastTap = now;
    _titleTaps++;
    if (_titleTaps >= 7) {
      _titleTaps = 0;
      _navigateToVault();
    }
  }

  void _navigateToVault() {
    HapticFeedback.mediumImpact();
    Navigator.of(context).pushReplacement(
      PageRouteBuilder(
        pageBuilder: (_, __, ___) => const SecretEntryScreen(),
        transitionsBuilder: (_, anim, __, child) =>
            FadeTransition(opacity: anim, child: child),
        transitionDuration: const Duration(milliseconds: 500),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF2F2F7),
      appBar: AppBar(
        backgroundColor: const Color(0xFFF2F2F7),
        elevation: 0,
        title: GestureDetector(
          onTap: _onTitleTap,
          child: const Text('الملاحظات',
            style: TextStyle(
              color: Colors.black, fontSize: 34,
              fontWeight: FontWeight.bold,
            ),
          ),
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.edit_square, color: Color(0xFFFF9F0A)),
            onPressed: () {},
          ),
        ],
      ),
      body: ListView.separated(
        padding: const EdgeInsets.all(16),
        itemCount: _fakeNotes.length,
        separatorBuilder: (_, __) => const Divider(height: 1),
        itemBuilder: (context, i) {
          final note = _fakeNotes[i];
          return ListTile(
            title: Text(note['title']!, style: const TextStyle(
              fontWeight: FontWeight.w600, fontSize: 16,
            )),
            subtitle: Text('${note['date']} · ${note['preview']}',
              style: const TextStyle(color: Colors.grey, fontSize: 13),
            ),
            trailing: const Icon(Icons.chevron_right, color: Colors.grey),
          );
        },
      ),
      floatingActionButton: FloatingActionButton(
        backgroundColor: const Color(0xFFFF9F0A),
        child: const Icon(Icons.add, color: Colors.white),
        onPressed: () {},
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════
//  WEATHER DISGUISE (minimal skeleton)
// ═══════════════════════════════════════════════════════════════════
class WeatherDisguise extends StatelessWidget {
  const WeatherDisguise({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [Color(0xFF1565C0), Color(0xFF42A5F5)],
          ),
        ),
        child: SafeArea(
          child: Column(
            children: [
              const SizedBox(height: 60),
              const Text('صنعاء', style: TextStyle(
                color: Colors.white, fontSize: 32, fontWeight: FontWeight.w300,
              )),
              const SizedBox(height: 8),
              const Text('صحو', style: TextStyle(color: Colors.white70, fontSize: 18)),
              const SizedBox(height: 16),
              const Text('28°', style: TextStyle(
                color: Colors.white, fontSize: 96, fontWeight: FontWeight.w100,
              )),
              const Icon(Icons.wb_sunny, color: Colors.yellow, size: 80),
              const SizedBox(height: 24),
              const Text('الحد الأقصى: 32° · الحد الأدنى: 21°',
                style: TextStyle(color: Colors.white70, fontSize: 15)),
            ],
          ),
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════
//  DIARY DISGUISE (minimal skeleton)
// ═══════════════════════════════════════════════════════════════════
class DiaryDisguise extends StatelessWidget {
  const DiaryDisguise({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFFFFDF5),
      appBar: AppBar(
        backgroundColor: const Color(0xFFFFFDF5),
        elevation: 0,
        title: const Text('مذكراتي', style: TextStyle(
          color: Color(0xFF5D4037), fontSize: 24, fontWeight: FontWeight.bold,
        )),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.book, size: 80, color: Colors.brown.shade200),
            const SizedBox(height: 16),
            Text('لا توجد مذكرات بعد',
              style: TextStyle(color: Colors.brown.shade300, fontSize: 16)),
          ],
        ),
      ),
    );
  }
}
