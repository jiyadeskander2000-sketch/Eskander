// ══════════════════════════════════════════════════════════════════
//  secure_notes_screen.dart
// ══════════════════════════════════════════════════════════════════
import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import '../../core/theme/app_theme.dart';
import '../../core/utils/encryption_service.dart';
import 'package:uuid/uuid.dart';

class SecureNotesScreen extends StatefulWidget {
  const SecureNotesScreen({super.key});
  @override State<SecureNotesScreen> createState() => _SecureNotesScreenState();
}

class _SecureNotesScreenState extends State<SecureNotesScreen> {
  final List<_NoteItem> _notes = [];
  final _uuid = const Uuid();

  static const List<Color> _noteColors = [
    Color(0xFF1C2B3A), Color(0xFF1A2F1A), Color(0xFF2F1A1A),
    Color(0xFF1A1A2F), Color(0xFF2F2A1A),
  ];

  Future<void> _addOrEditNote([_NoteItem? existing]) async {
    final titleCtrl = TextEditingController(text: existing?.title ?? '');
    final bodyCtrl  = TextEditingController(
      text: existing != null
          ? await EncryptionService.decryptText(existing.encryptedContent).catchError((_) => '')
          : '',
    );
    int colorIdx = existing?.colorIdx ?? 0;

    final saved = await showModalBottomSheet<bool>(
      context: context, isScrollControlled: true,
      backgroundColor: AppTheme.cardDark,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24))),
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setModal) => Padding(
          padding: EdgeInsets.fromLTRB(
            20, 20, 20, MediaQuery.of(ctx).viewInsets.bottom + 20),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Expanded(child: Text('ملاحظة سرية',
                    style: Theme.of(ctx).textTheme.titleLarge)),
                  TextButton(
                    onPressed: () => Navigator.pop(ctx, true),
                    child: const Text('حفظ', style: TextStyle(color: AppTheme.vaultAccent)),
                  ),
                ],
              ),
              const SizedBox(height: 12),
              // Color selector
              Row(
                children: _noteColors.asMap().entries.map((e) => GestureDetector(
                  onTap: () => setModal(() => colorIdx = e.key),
                  child: Container(
                    width: 28, height: 28,
                    margin: const EdgeInsets.only(right: 8),
                    decoration: BoxDecoration(
                      color: e.value,
                      shape: BoxShape.circle,
                      border: Border.all(
                        color: colorIdx == e.key
                            ? AppTheme.vaultAccent
                            : Colors.transparent,
                        width: 2,
                      ),
                    ),
                  ),
                )).toList(),
              ),
              const SizedBox(height: 12),
              TextField(
                controller: titleCtrl,
                style: const TextStyle(color: AppTheme.textPrimary, fontSize: 18,
                  fontWeight: FontWeight.w600),
                decoration: const InputDecoration(
                  hintText: 'العنوان', border: InputBorder.none,
                  hintStyle: TextStyle(color: AppTheme.textMuted, fontSize: 18),
                ),
              ),
              TextField(
                controller: bodyCtrl, maxLines: 8,
                style: const TextStyle(color: AppTheme.textSecondary, fontSize: 15),
                decoration: const InputDecoration(
                  hintText: 'اكتب ملاحظتك هنا...', border: InputBorder.none,
                  hintStyle: TextStyle(color: AppTheme.textMuted),
                ),
              ),
            ],
          ),
        ),
      ),
    );

    if (saved != true) return;
    if (titleCtrl.text.isEmpty && bodyCtrl.text.isEmpty) return;

    final encrypted = await EncryptionService.encryptText(bodyCtrl.text);

    setState(() {
      if (existing != null) {
        final idx = _notes.indexOf(existing);
        if (idx != -1) {
          _notes[idx] = _NoteItem(
            id: existing.id, title: titleCtrl.text,
            encryptedContent: encrypted, colorIdx: colorIdx,
            createdAt: existing.createdAt, modifiedAt: DateTime.now(),
          );
        }
      } else {
        _notes.insert(0, _NoteItem(
          id: _uuid.v4(), title: titleCtrl.text,
          encryptedContent: encrypted, colorIdx: colorIdx,
          createdAt: DateTime.now(), modifiedAt: DateTime.now(),
        ));
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.surfaceDark,
      appBar: AppBar(title: const Text('الملاحظات السرية')),
      body: _notes.isEmpty
          ? Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const Icon(Icons.sticky_note_2_outlined,
                    size: 60, color: AppTheme.textMuted),
                  const SizedBox(height: 12),
                  Text('لا توجد ملاحظات',
                    style: Theme.of(context).textTheme.titleMedium?.copyWith(
                      color: AppTheme.textSecondary)),
                ],
              ).animate().fadeIn(),
            )
          : GridView.builder(
              padding: const EdgeInsets.all(16),
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 2, crossAxisSpacing: 12, mainAxisSpacing: 12,
                childAspectRatio: 0.9,
              ),
              itemCount: _notes.length,
              itemBuilder: (ctx, i) {
                final note = _notes[i];
                return GestureDetector(
                  onTap: () => _addOrEditNote(note),
                  child: Container(
                    padding: const EdgeInsets.all(14),
                    decoration: BoxDecoration(
                      color: _noteColors[note.colorIdx],
                      borderRadius: BorderRadius.circular(16),
                      border: Border.all(color: AppTheme.borderColor),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(note.title,
                          style: const TextStyle(
                            color: AppTheme.textPrimary, fontWeight: FontWeight.w600,
                            fontSize: 15,
                          ), maxLines: 2, overflow: TextOverflow.ellipsis),
                        const SizedBox(height: 8),
                        Text('••••••••••',
                          style: TextStyle(color: AppTheme.textMuted, fontSize: 18,
                            letterSpacing: 2)),
                        const Spacer(),
                        Text(
                          '${note.modifiedAt.day}/${note.modifiedAt.month}/${note.modifiedAt.year}',
                          style: const TextStyle(
                            color: AppTheme.textMuted, fontSize: 11),
                        ),
                      ],
                    ),
                  ).animate().fadeIn(duration: 300.ms, delay: (i * 40).ms),
                );
              },
            ),
      floatingActionButton: FloatingActionButton(
        onPressed: () => _addOrEditNote(),
        backgroundColor: AppTheme.vaultAccent,
        foregroundColor: AppTheme.ghostBlue,
        child: const Icon(Icons.add),
      ),
    );
  }
}

class _NoteItem {
  final String id, title, encryptedContent;
  final int    colorIdx;
  final DateTime createdAt, modifiedAt;
  const _NoteItem({
    required this.id, required this.title, required this.encryptedContent,
    required this.colorIdx, required this.createdAt, required this.modifiedAt,
  });
}


// ══════════════════════════════════════════════════════════════════
//  attempts_log_screen.dart
// ══════════════════════════════════════════════════════════════════
class AttemptsLogScreen extends StatelessWidget {
  const AttemptsLogScreen({super.key});

  // Mock data — in real app comes from SQLite
  static final _mockAttempts = [
    _AttemptEntry(time: DateTime.now().subtract(const Duration(hours: 2)),
      success: true,  method: 'صوت', imagePath: null),
    _AttemptEntry(time: DateTime.now().subtract(const Duration(hours: 5)),
      success: false, method: 'نقر',  imagePath: 'intruder_shot.jpg'),
    _AttemptEntry(time: DateTime.now().subtract(const Duration(days: 1)),
      success: true,  method: 'صوت', imagePath: null),
    _AttemptEntry(time: DateTime.now().subtract(const Duration(days: 1, hours: 3)),
      success: false, method: 'نمط', imagePath: 'intruder_shot2.jpg'),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.surfaceDark,
      appBar: AppBar(title: const Text('سجل المحاولات')),
      body: ListView.separated(
        padding: const EdgeInsets.all(16),
        itemCount: _mockAttempts.length,
        separatorBuilder: (_, __) => const SizedBox(height: 8),
        itemBuilder: (ctx, i) {
          final a = _mockAttempts[i];
          return Container(
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(
              color: AppTheme.cardDark,
              borderRadius: BorderRadius.circular(14),
              border: Border.all(
                color: a.success
                    ? AppTheme.successGreen.withOpacity(0.3)
                    : AppTheme.dangerRed.withOpacity(0.3),
              ),
            ),
            child: Row(
              children: [
                Container(
                  width: 40, height: 40,
                  decoration: BoxDecoration(
                    color: (a.success ? AppTheme.successGreen : AppTheme.dangerRed)
                        .withOpacity(0.1),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: Icon(
                    a.success ? Icons.check_circle : Icons.block,
                    color: a.success ? AppTheme.successGreen : AppTheme.dangerRed,
                    size: 20,
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        a.success ? 'دخول ناجح' : 'محاولة فاشلة',
                        style: TextStyle(
                          color: a.success ? AppTheme.successGreen : AppTheme.dangerRed,
                          fontWeight: FontWeight.w600, fontSize: 14,
                        ),
                      ),
                      Text('طريقة: ${a.method} · ${_formatTime(a.time)}',
                        style: Theme.of(ctx).textTheme.bodyMedium),
                    ],
                  ),
                ),
                if (a.imagePath != null)
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                    decoration: BoxDecoration(
                      color: AppTheme.dangerRed.withOpacity(0.1),
                      borderRadius: BorderRadius.circular(6),
                    ),
                    child: const Text('📷 صورة',
                      style: TextStyle(color: AppTheme.dangerRed, fontSize: 11)),
                  ),
              ],
            ),
          ).animate().fadeIn(duration: 300.ms, delay: (i * 50).ms);
        },
      ),
    );
  }

  String _formatTime(DateTime t) {
    final diff = DateTime.now().difference(t);
    if (diff.inMinutes < 60) return 'منذ ${diff.inMinutes} دقيقة';
    if (diff.inHours < 24)   return 'منذ ${diff.inHours} ساعة';
    return 'منذ ${diff.inDays} يوم';
  }
}

class _AttemptEntry {
  final DateTime time;
  final bool     success;
  final String   method;
  final String?  imagePath;
  const _AttemptEntry({
    required this.time, required this.success,
    required this.method, this.imagePath,
  });
}


// ══════════════════════════════════════════════════════════════════
//  settings_screen.dart
// ══════════════════════════════════════════════════════════════════
class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});
  @override State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  bool _captureOnFail      = true;
  bool _screenshotBlock    = true;
  bool _voiceAuth          = true;
  bool _isDarkMode         = true;
  int  _maxAttempts        = 5;
  String _disguiseMode     = 'calculator';
  String _entryMethod      = 'voice';

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.surfaceDark,
      appBar: AppBar(title: const Text('الإعدادات')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          _section('المظهر', [
            _switchTile('الوضع الداكن', Icons.dark_mode, _isDarkMode,
              (v) => setState(() => _isDarkMode = v)),
            _dropdownTile('تمويه التطبيق', Icons.visibility_off, _disguiseMode,
              ['calculator', 'notes', 'weather', 'diary'],
              ['آلة حاسبة', 'ملاحظات', 'طقس', 'مفكرة'],
              (v) => setState(() => _disguiseMode = v!)),
          ]),
          const SizedBox(height: 20),
          _section('طريقة الدخول السري', [
            _dropdownTile('وسيلة الدخول', Icons.key, _entryMethod,
              ['voice', 'tap', 'pattern', 'swipe'],
              ['بصمة الصوت', 'تسلسل النقر', 'النمط', 'السحب'],
              (v) => setState(() => _entryMethod = v!)),
            _actionTile('تغيير كلمة السر الصوتية', Icons.mic, AppTheme.vaultAccent, () {}),
            _actionTile('ضبط تسلسل النقر', Icons.touch_app, AppTheme.warningAmber, () {}),
          ]),
          const SizedBox(height: 20),
          _section('الأمان', [
            _switchTile('التقاط صورة عند الفشل', Icons.camera, _captureOnFail,
              (v) => setState(() => _captureOnFail = v)),
            _switchTile('منع لقطة الشاشة', Icons.block, _screenshotBlock,
              (v) => setState(() => _screenshotBlock = v)),
            _switchTile('المصادقة الصوتية', Icons.record_voice_over, _voiceAuth,
              (v) => setState(() => _voiceAuth = v)),
            _sliderTile('عدد المحاولات المسموح', Icons.lock_clock, _maxAttempts,
              1, 10, (v) => setState(() => _maxAttempts = v.round())),
          ]),
          const SizedBox(height: 20),
          _section('النسخ الاحتياطي', [
            _actionTile('نسخ احتياطي سحابي', Icons.cloud_upload, AppTheme.vaultAccent, () {}),
            _actionTile('استعادة البيانات', Icons.cloud_download, AppTheme.successGreen, () {}),
          ]),
          const SizedBox(height: 20),
          _section('ذكاء اصطناعي', [
            _actionTile('توليد كلمة سر ذكية', Icons.auto_awesome, AppTheme.warningAmber, () {
              final pass = EncryptionService.generateSmartPassword();
              showDialog(
                context: context,
                builder: (_) => AlertDialog(
                  backgroundColor: AppTheme.cardDark,
                  title: const Text('كلمة سر مقترحة',
                    style: TextStyle(color: AppTheme.textPrimary)),
                  content: SelectableText(pass,
                    style: const TextStyle(
                      color: AppTheme.vaultAccent, fontSize: 18,
                      fontWeight: FontWeight.bold, letterSpacing: 2,
                    )),
                  actions: [
                    TextButton(onPressed: () => Navigator.pop(context),
                      child: const Text('موافق')),
                  ],
                ),
              );
            }),
          ]),
          const SizedBox(height: 80),
        ],
      ),
    );
  }

  Widget _section(String title, List<Widget> children) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.only(bottom: 10, right: 4),
          child: Text(title.toUpperCase(),
            style: const TextStyle(
              color: AppTheme.textMuted, fontSize: 11,
              fontWeight: FontWeight.w600, letterSpacing: 1,
            ),
          ),
        ),
        Container(
          decoration: BoxDecoration(
            color: AppTheme.cardDark,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: AppTheme.borderColor),
          ),
          child: Column(children: children),
        ),
      ],
    );
  }

  Widget _switchTile(String label, IconData icon, bool value, ValueChanged<bool> onChanged) {
    return ListTile(
      leading: Icon(icon, color: AppTheme.textSecondary, size: 20),
      title: Text(label, style: Theme.of(context).textTheme.bodyLarge),
      trailing: Switch.adaptive(
        value: value, onChanged: onChanged,
        activeColor: AppTheme.vaultAccent,
      ),
    );
  }

  Widget _dropdownTile(String label, IconData icon, String value,
    List<String> values, List<String> labels, ValueChanged<String?> onChanged) {
    return ListTile(
      leading: Icon(icon, color: AppTheme.textSecondary, size: 20),
      title: Text(label, style: Theme.of(context).textTheme.bodyLarge),
      trailing: DropdownButton<String>(
        value: value, dropdownColor: AppTheme.cardDarker,
        underline: const SizedBox(),
        style: const TextStyle(color: AppTheme.textPrimary, fontSize: 13),
        items: values.asMap().entries.map((e) =>
          DropdownMenuItem(value: e.value, child: Text(labels[e.key]))).toList(),
        onChanged: onChanged,
      ),
    );
  }

  Widget _actionTile(String label, IconData icon, Color color, VoidCallback onTap) {
    return ListTile(
      leading: Icon(icon, color: color, size: 20),
      title: Text(label, style: Theme.of(context).textTheme.bodyLarge),
      trailing: Icon(Icons.arrow_forward_ios, size: 14, color: AppTheme.textMuted),
      onTap: onTap,
    );
  }

  Widget _sliderTile(String label, IconData icon, int value,
    double min, double max, ValueChanged<double> onChanged) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(icon, color: AppTheme.textSecondary, size: 20),
              const SizedBox(width: 12),
              Text(label, style: Theme.of(context).textTheme.bodyLarge),
              const Spacer(),
              Text('$value', style: const TextStyle(
                color: AppTheme.vaultAccent, fontWeight: FontWeight.bold)),
            ],
          ),
          Slider(
            value: value.toDouble(), min: min, max: max, divisions: (max - min).toInt(),
            activeColor: AppTheme.vaultAccent,
            inactiveColor: AppTheme.borderColor,
            onChanged: onChanged,
          ),
        ],
      ),
    );
  }
}
