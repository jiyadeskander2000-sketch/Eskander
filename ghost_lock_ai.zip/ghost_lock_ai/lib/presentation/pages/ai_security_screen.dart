import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_animate/flutter_animate.dart';
import '../../core/theme/app_theme.dart';
import '../../core/utils/ghost_ai.dart';
import '../../data/datasources/vault_database.dart';

class AiSecurityScreen extends StatefulWidget {
  const AiSecurityScreen({super.key});
  @override State<AiSecurityScreen> createState() => _AiSecurityScreenState();
}

class _AiSecurityScreenState extends State<AiSecurityScreen> {
  SuspicionReport? _report;
  List<SecurityTip> _tips    = [];
  List<SmartSuggestion> _suggestions = [];
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final attempts = await VaultDatabase.getAttempts(limit: 20);
    final snapshots = attempts.map((a) => AttemptSnapshot(
      timestamp: a.timestamp, wasSuccessful: a.wasSuccessful,
    )).toList();

    final report  = GhostAI.analyzeAttempts(snapshots);
    final tips    = GhostAI.getSecurityTips(
      voiceEnabled: true, biometricEnabled: false,
      captureOnFail: true, maxAttempts: 5,
      failCount: snapshots.where((s) => !s.wasSuccessful).length,
    );
    final suggestions = GhostAI.generateSmartSuggestions();

    setState(() {
      _report = report; _tips = tips;
      _suggestions = suggestions; _loading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.surfaceDark,
      appBar: AppBar(
        title: const Text('الذكاء الاصطناعي'),
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh),
            onPressed: () { setState(() => _loading = true); _load(); },
          ),
        ],
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator(color: AppTheme.vaultAccent))
          : ListView(
              padding: const EdgeInsets.all(16),
              children: [
                _buildSecurityScore(),
                const SizedBox(height: 20),
                if (_tips.isNotEmpty) ...[
                  _sectionLabel('توصيات الذكاء الاصطناعي'),
                  const SizedBox(height: 12),
                  ..._tips.asMap().entries.map((e) =>
                    _buildTipCard(e.value, e.key)),
                  const SizedBox(height: 20),
                ],
                _sectionLabel('كلمات سر مقترحة'),
                const SizedBox(height: 12),
                ..._suggestions.asMap().entries.map((e) =>
                  _buildSuggestionCard(e.value, e.key)),
                const SizedBox(height: 20),
                _buildVoiceEnrollCard(),
                const SizedBox(height: 80),
              ],
            ),
    );
  }

  Widget _sectionLabel(String label) => Text(
    label.toUpperCase(),
    style: const TextStyle(
      color: AppTheme.textMuted, fontSize: 11,
      fontWeight: FontWeight.w600, letterSpacing: 1,
    ),
  );

  Widget _buildSecurityScore() {
    if (_report == null) return const SizedBox.shrink();
    final r = _report!;
    final color = r.isCritical
        ? AppTheme.dangerRed
        : r.isWarning
            ? AppTheme.warningAmber
            : AppTheme.successGreen;
    final icon = r.isCritical
        ? Icons.gpp_bad
        : r.isWarning
            ? Icons.gpp_maybe
            : Icons.verified_user;

    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [color.withOpacity(0.12), AppTheme.cardDark],
          begin: Alignment.topLeft, end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: color.withOpacity(0.3)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(icon, color: color, size: 28),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('مستوى الأمان',
                      style: TextStyle(color: color,
                        fontWeight: FontWeight.w700, fontSize: 16)),
                    Text(r.message,
                      style: Theme.of(context).textTheme.bodyMedium),
                  ],
                ),
              ),
              // Score circle
              Container(
                width: 56, height: 56,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: color.withOpacity(0.1),
                  border: Border.all(color: color.withOpacity(0.4), width: 2),
                ),
                child: Center(
                  child: Text('${100 - r.score}',
                    style: TextStyle(
                      color: color, fontSize: 18,
                      fontWeight: FontWeight.w800,
                    )),
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          // Score bar
          ClipRRect(
            borderRadius: BorderRadius.circular(4),
            child: LinearProgressIndicator(
              value: (100 - r.score) / 100,
              backgroundColor: AppTheme.borderColor,
              valueColor: AlwaysStoppedAnimation(color),
              minHeight: 6,
            ),
          ),
          const SizedBox(height: 12),
          Row(
            children: [
              _statBadge('محاولات فاشلة', '${r.failCount}', AppTheme.dangerRed),
              const SizedBox(width: 10),
              _statBadge('سريعة', '${r.rapidFails}', AppTheme.warningAmber),
            ],
          ),
        ],
      ),
    ).animate().fadeIn(duration: 500.ms).slideY(begin: 0.05);
  }

  Widget _statBadge(String label, String value, Color color) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      decoration: BoxDecoration(
        color: color.withOpacity(0.08),
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: color.withOpacity(0.2)),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Text(value,
            style: TextStyle(color: color,
              fontWeight: FontWeight.w700, fontSize: 15)),
          const SizedBox(width: 4),
          Text(label,
            style: const TextStyle(color: AppTheme.textSecondary, fontSize: 11)),
        ],
      ),
    );
  }

  Widget _buildTipCard(SecurityTip tip, int index) {
    final color = tip.priority == 'high'
        ? AppTheme.dangerRed
        : tip.priority == 'medium'
            ? AppTheme.warningAmber
            : AppTheme.textSecondary;

    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppTheme.cardDark,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: AppTheme.borderColor),
      ),
      child: Row(
        children: [
          Text(tip.icon, style: const TextStyle(fontSize: 26)),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(tip.title,
                  style: Theme.of(context).textTheme.titleMedium?.copyWith(
                    fontSize: 14)),
                const SizedBox(height: 3),
                Text(tip.description,
                  style: Theme.of(context).textTheme.bodyMedium),
              ],
            ),
          ),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
            decoration: BoxDecoration(
              color: color.withOpacity(0.1),
              borderRadius: BorderRadius.circular(6),
            ),
            child: Text(
              tip.priority == 'high' ? 'عاجل'
                  : tip.priority == 'medium' ? 'مهم' : 'اختياري',
              style: TextStyle(color: color, fontSize: 10,
                fontWeight: FontWeight.w600),
            ),
          ),
        ],
      ),
    ).animate().fadeIn(duration: 300.ms, delay: (index * 60).ms);
  }

  Widget _buildSuggestionCard(SmartSuggestion s, int index) {
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppTheme.cardDark,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: AppTheme.borderColor),
      ),
      child: Row(
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(s.description,
                  style: Theme.of(context).textTheme.bodyMedium),
                const SizedBox(height: 6),
                Text(s.passphrase,
                  style: const TextStyle(
                    color: AppTheme.vaultAccent, fontSize: 16,
                    fontWeight: FontWeight.w700, letterSpacing: 1.5,
                    fontFamily: 'monospace',
                  )),
              ],
            ),
          ),
          const SizedBox(width: 12),
          Column(
            children: [
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                decoration: BoxDecoration(
                  color: AppTheme.successGreen.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(6),
                ),
                child: Text(s.strength,
                  style: const TextStyle(
                    color: AppTheme.successGreen, fontSize: 10,
                    fontWeight: FontWeight.w600)),
              ),
              const SizedBox(height: 8),
              GestureDetector(
                onTap: () {
                  Clipboard.setData(ClipboardData(text: s.passphrase));
                  HapticFeedback.selectionClick();
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(
                      content: Text('تم نسخ كلمة السر'),
                      backgroundColor: AppTheme.vaultAccent,
                      behavior: SnackBarBehavior.floating,
                      duration: Duration(seconds: 2),
                    ),
                  );
                },
                child: const Icon(Icons.copy_outlined,
                  color: AppTheme.textSecondary, size: 18),
              ),
            ],
          ),
        ],
      ),
    ).animate().fadeIn(duration: 300.ms, delay: (index * 70).ms);
  }

  Widget _buildVoiceEnrollCard() {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: AppTheme.vaultAccent.withOpacity(0.05),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppTheme.vaultAccent.withOpacity(0.2)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const Icon(Icons.record_voice_over,
                color: AppTheme.vaultAccent, size: 24),
              const SizedBox(width: 10),
              Text('تسجيل بصمة الصوت',
                style: Theme.of(context).textTheme.titleMedium),
            ],
          ),
          const SizedBox(height: 10),
          Text(
            'سجّل صوتك ليتعرف عليك التطبيق تلقائياً. '
            'يتطلب 3 عينات صوتية لكل منها 3 ثوانٍ.',
            style: Theme.of(context).textTheme.bodyMedium,
          ),
          const SizedBox(height: 16),
          SizedBox(
            width: double.infinity,
            child: ElevatedButton.icon(
              onPressed: () async {
                final ok = await GhostAI.enrollOwnerVoice();
                if (!mounted) return;
                ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                  content: Text(ok
                    ? 'تم تسجيل بصمة الصوت بنجاح'
                    : 'فشل التسجيل، حاول مجدداً'),
                  backgroundColor: ok
                    ? AppTheme.successGreen
                    : AppTheme.dangerRed,
                  behavior: SnackBarBehavior.floating,
                ));
              },
              icon: const Icon(Icons.mic),
              label: const Text('ابدأ التسجيل'),
            ),
          ),
        ],
      ),
    ).animate().fadeIn(duration: 400.ms, delay: 300.ms);
  }
}
